#pragma once

extern const uint8_t SmallFont[];
extern const uint8_t BigFont[];
extern const uint8_t SevenSegNumFont[];
extern const uint8_t FONT8x15[];

