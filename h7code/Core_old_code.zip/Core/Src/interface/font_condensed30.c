// family=Ubuntu Condensed size=19.5
// height=30
// bytes count=8584  bits_per_pixel=2
const uint32_t font_condensed30[2146]= {
0x203191e, 
// start char =31 count=95
0x5f001f, 
// start char =1040 count=64
0x400410, 
// start char =176 count=2
0x200b0, 
// char infos count=161
0x19000146, 0xb0000, 
0x19000146, 0x50000, 
0x7010146, 0x71204, 
0x501014b, 0xa0708, 
0x701014f, 0xf120d, 
0x501015e, 0xb1709, 
0x701016b, 0x11120f, 
0x701017c, 0xd120d, 
0x501018b, 0x60703, 
0x401018d, 0x71a07, 
0x4000199, 0x71a06, 
0x60001a3, 0xa090a, 
0xc0101a9, 0xb0a0a, 
0x160001b0, 0x60705, 
0xf0001b3, 0x60306, 
0x150101b5, 0x60404, 
0x50001b6, 0x71908, 
0x70101c3, 0xb1209, 
0x70101ce, 0xb1207, 
0x70101d6, 0xb1209, 
0x70101e1, 0xb1209, 
0x70101ec, 0xb120a, 
0x70101f8, 0xb1209, 
0x7010203, 0xb1209, 
0x701020e, 0xb1209, 
0x7010219, 0xb1209, 
0x7010224, 0xb1209, 
0xb01022f, 0x60e04, 
0xb000233, 0x61305, 
0xb010239, 0xb0c09, 
0xe010240, 0xb070a, 
0xb010245, 0xb0c09, 
0x700024c, 0x91209, 
0x7010257, 0x151513, 
0x7000270, 0xd120d, 
0x702027f, 0xe120b, 
0x701028c, 0xc120b, 
0x7020299, 0xf120c, 
0x70202a7, 0xc1209, 
0x70202b2, 0xb1209, 
0x70102bd, 0xe120b, 
0x70202ca, 0xf120b, 
0x70202d7, 0x71203, 
0x70002db, 0xa1209, 
0x70202e6, 0xd120c, 
0x70202f4, 0xb1209, 
0x70102ff, 0x131211, 
0x7020313, 0xf120b, 
0x7010320, 0x10120e, 
0x7020330, 0xd120a, 
0x701033c, 0x10170e, 
0x7020351, 0xd120b, 
0x700035e, 0xa120a, 
0x700036a, 0xb120b, 
0x7020377, 0xe120b, 
0x7000384, 0xd120d, 
0x7010393, 0x141212, 
0x70003a8, 0xc120c, 
0x70003b6, 0xc120c, 
0x70003c4, 0xb120b, 
0x50203d1, 0x71906, 
0x50003db, 0x71908, 
0x50003e8, 0x71905, 
0x70003f0, 0xb0a0b, 
0x1c0003f7, 0xa020a, 
0x40003f9, 0x80606, 
0xb0103fc, 0xb0e09, 
0x4020404, 0xc1509, 
0xb010410, 0x90e08, 
0x4010417, 0xc150a, 
0xb010425, 0xb0e0a, 
0x502042e, 0x81407, 
0xb010437, 0xc130a, 
0x4020443, 0xd1509, 
0x601044f, 0x61304, 
0x6000454, 0x61805, 
0x402045c, 0xb1509, 
0x4010468, 0x61505, 
0xb02046f, 0x120e0f, 
0xb02047d, 0xd0e09, 
0xb010485, 0xc0e0a, 
0xb02048e, 0xc1309, 
0xb010499, 0xc130a, 
0xb0204a5, 0x90e07, 
0xb0004ac, 0x90e09, 
0x60104b4, 0x81307, 
0xb0104bd, 0xc0e0a, 
0xb0004c6, 0xa0e0a, 
0xb0004cf, 0xf0e0f, 
0xb0004dd, 0xa0e0a, 
0xb0004e6, 0xa130a, 
0xb0004f2, 0x90e09, 
0x50004fa, 0x71907, 
0x5020505, 0x71903, 
0x500050a, 0x71906, 
0x7000514, 0xd120d, 
0x7020523, 0xd120a, 
0x702052f, 0xe120b, 
0x702053c, 0xb1209, 
0x7000547, 0xf170f, 
0x702055d, 0xc1209, 
0x7000568, 0x111211, 
0x700057c, 0xb120a, 
0x7020588, 0xf120b, 
0x1020595, 0xf180b, 
0x70205a6, 0xd120c, 
0x70005b4, 0xf120d, 
0x70105c3, 0x131211, 
0x70205d7, 0xf120b, 
0x70105e4, 0x10120e, 
0x70205f4, 0xf120b, 
0x7020601, 0xd120a, 
0x701060d, 0xc120b, 
0x700061a, 0xb120b, 
0x7000627, 0xc120c, 
0x5010635, 0x11140f, 
0x7000648, 0xc120c, 
0x7020656, 0xf170d, 
0x7010669, 0xd120b, 
0x7020676, 0x141210, 
0x7020688, 0x141712, 
0x70006a2, 0xe120e, 
0x70206b2, 0x141210, 
0x70206c4, 0xd120a, 
0x70006d0, 0xc120b, 
0x70206dd, 0x161213, 
0x70006f3, 0xd120c, 
0xb010701, 0xb0e09, 
0x4010709, 0xc150b, 
0xb020718, 0xc0e09, 
0xb020720, 0x90e07, 
0xb000727, 0xc120d, 
0xb010736, 0xb0e0a, 
0xb00073f, 0xe0e0e, 
0xb00074c, 0xa0e09, 
0xb020754, 0xd0e09, 
0x502075c, 0xd1409, 
0xb020768, 0xb0e09, 
0xb000770, 0xd0e0b, 
0xb01077a, 0x100e0d, 
0xb020786, 0xd0e09, 
0xb01078e, 0xc0e0a, 
0xb020797, 0xc0e09, 
0xb02079f, 0xc1309, 
0xb0107aa, 0x90e08, 
0xb0007b1, 0xa0e0a, 
0xb0007ba, 0xa130a, 
0x50107c6, 0xf190e, 
0xb0007dc, 0xa0e0a, 
0xb0207e5, 0xc120b, 
0xb0107f2, 0xc0e09, 
0xb0207fa, 0x120e0e, 
0xb020807, 0x121210, 
0xb000819, 0xc0e0c, 
0xb020824, 0x110e0e, 
0xb020831, 0xb0e09, 
0xb000839, 0xa0e09, 
0xb020841, 0x110e0e, 
0xb01084e, 0xb0e09, 
0x6000856, 0x70607, 
0xc010859, 0xb0d0a, 
//char=' ' offset=(0, 25) width=0 height=0 xadvance=11.1719

//char=' ' offset=(0, 25) width=0 height=0 xadvance=5.0625

//char='!' offset=(1, 7) width=4 height=18 xadvance=6.82813
//.WWO
//.WWO
//.WWO
//.WWO
//.WWO
//.WWO
//.OWO
//.OWO
//.OWo
//.OWo
//.oWo
//.oW.
//..o.
//....
//....
//.OWO
//.WWW
//.OWo
0xbcbcbcbc, 0xb8b8bcbc, 0x34747878, 0xb8000010, 0x78fc, 
//char='"' offset=(1, 5) width=8 height=7 xadvance=9.8125
//.WW..WW.
//.WW..WW.
//.WW..WW.
//.WW..WW.
//.WO..WW.
//.WO..WO.
//.Oo..oo.
0x3c3c3c3c, 0x3c3c3c3c, 0x2c2c3c2c, 0x1418, 
//char='#' offset=(1, 7) width=13 height=18 xadvance=14.7344
//....WW...WW..
//....WO...WW..
//...oWO...WO..
//...oWo..oWo..
//WWWWWWWWWWWWO
//OOOWWOOOWWOOo
//...WW...WW...
//...WW...WW...
//...WO...WW...
//...WO...WO...
//..oWo..oWO...
//OOWWWOOWWWOOo
//WWWWWWWWWWWWO
//..OW...OW....
//..WW...WW....
//..WW...WW....
//..WO...WW....
//.oWO...WO....
0x3c0f00, 0xb400f02c, 0x41d002c0, 0xffffff07, 0x6beafaa, 0xf000f03c, 0x2c003c0, 0x2c0b000f, 0x80b41d00, 0xff6bfafe, 0x382ffff, 0x3c0f000e, 0xf03c00, 0xd003c0b0, 0xb02, 
//char='$' offset=(1, 5) width=9 height=23 xadvance=11.1719
//...oWO...
//...oWO...
//...oWO...
//..oWWWWO.
//.oWWWWWW.
//.WWO.....
//oWW......
//oWW......
//.WWo.....
//.OWWo....
//..WWWO...
//...OWWW..
//....oWWW.
//.....oWWo
//......WWO
//......OWO
//......WWO
//.WoooOWW.
//oWWWWWWO.
//..oWWW...
//...oWO...
//...oWO...
//...oWO...
0x2d000b40, 0xf400b400, 0xf0fff42f, 0x4003d002, 0x7c000f, 0xbf0007e0, 0xfe000, 0x7d000fd, 0xb8002f00, 0xe572f000, 0xf40bffd3, 0xb4003, 0xb4002d, 
//char='%' offset=(1, 7) width=15 height=18 xadvance=16.7656
//.oWWO....oWO...
//.WWOWO...OWo...
//OWo.WW...WW....
//OW..OWo.oWO....
//OW..OWo.WW.....
//OW..OW.oWO.....
//oWO.WW.OWo.....
//.WWWWO.WW......
//..OOo.oWO.oOo..
//......WW.OWWWO.
//.....oWO.WO.WW.
//.....OWooWo.oWo
//.....WW.OWo.oWo
//....OWo.OWo.oWo
//....WW..oWo.oWo
//...oWO..oWO.OWo
//...OWo...WWOWW.
//...WW.....WWW..
0xb402f4, 0xe01e02ef, 0x3803c0f1, 0xe00b478, 0x83800f1e, 0xf2d002d3, 0x2ff00078, 0xd1a0000f, 0x3c000192, 0xcb4002fe, 0x75e000f2, 0x1e3c0074, 0x4787801d, 0xd1d0f007, 0x78b42d01, 0xfbc0780, 0xfc00f0, 
//char='&' offset=(1, 7) width=13 height=18 xadvance=13.2813
//...OWWOo.....
//..WWWWWW.....
//.oWW..OWO....
//.OWo..oWO....
//.OWO..oWO....
//.oWW..WWo....
//..WWoOWO.....
//..oWWWW......
//...WWW.......
//..WWWWO..oWo.
//.WWooWWo.OWo.
//oWW..OWW.WW..
//OWO...OWOWW..
//WWo....WWWo..
//OWO....oWWo..
//oWW....WWWO..
//.OWWOOWWOWWo.
//..oWWWOo.oWW.
0xc0006f80, 0xf4003ff, 0xb41e002e, 0x2d0b800, 0x7c3d0, 0xf4000b9f, 0xfc0000f, 0xd0bfc000, 0x4787d7c1, 0x2e0f3e0f, 0x7c3ee0, 0xf402e07f, 0xbf00f41, 0x407efaf8, 0x3d1bf, 
//char=''' offset=(1, 5) width=3 height=7 xadvance=5.76563
//.WW
//.WW
//.WW
//.WW
//.WO
//.WO
//.Oo
0x2cf3cf3c, 0x18b, 
//char='(' offset=(1, 4) width=7 height=26 xadvance=7.40625
//.......
//....WW.
//...OWW.
//...WWo.
//..oWW..
//..WWO..
//..WW...
//.oWW...
//.OWO...
//.OWO...
//.WWo...
//.WWo...
//.WWo...
//.WWo...
//.WWo...
//.WWo...
//.WWo...
//.OWO...
//.oWW...
//..WW...
//..WWo..
//..OWO..
//...WW..
//...WWO.
//...oWW.
//....Oo.
0x3c00000, 0xd01f00f8, 0xf00bc03, 0xb803d0, 0xf007c02e, 0x1f007c01, 0x1f007c0, 0x402e007c, 0xf003c00f, 0x3c00b801, 0xf402f00, 0x180, 
//char=')' offset=(0, 4) width=6 height=26 xadvance=7.40625
//......
//OWo...
//oWW...
//.WWo..
//.oWW..
//..WW..
//..OWO.
//..oWO.
//..oWW.
//...WW.
//...WWo
//...WWo
//...WWo
//...WWo
//...WWo
//...WWo
//...WW.
//...WW.
//..oWW.
//..OWO.
//..WWo.
//.oWW..
//.OWO..
//.WW...
//OWO...
//.O....
0x3d01e000, 0xf407c0, 0x2d02e00f, 0xc03c03d0, 0x7c07c07, 0x7c07c07c, 0xd03c03c0, 0x41f02e03, 0x3c0b80f, 0x802e, 
//char='*' offset=(0, 6) width=10 height=9 xadvance=10.0469
//..........
//....WW....
//.o..WW..o.
//.OWOOOOWW.
//.WWWWWWWW.
//...oWWo...
//..oWOOWo..
//..WW.oWW..
//...o..o...
0xf0000000, 0x810f0400, 0xfffc3eab, 0xd001f403, 0xf4f007a, 0x1040, 
//char='+' offset=(1, 12) width=10 height=10 xadvance=11.1719
//....o.....
//...oWO....
//...oWO....
//...oWO....
//WWWWWWWWW.
//WWWWWWWWW.
//...oWO....
//...oWO....
//...oWO....
//...oWO....
0xb4000100, 0xb4000, 0xffff00b4, 0x403ffff3, 0xb4000b, 0xb4000b40, 0x0, 
//char=',' offset=(0, 22) width=5 height=7 xadvance=6.03125
//..WWo
//..WWo
//..WW.
//..WW.
//.oWO.
//.OWo.
//.OO..
0xf07c1f0, 0x81e0b43c, 0x2, 
//char='-' offset=(0, 15) width=6 height=3 xadvance=6.04688
//......
//oWWWWo
//oWWWWo
0xfd7fd000, 0x7, 
//char='.' offset=(1, 21) width=4 height=4 xadvance=6.03125
//....
//.WW.
//oWWO
//.WW.
0x3cbd3c00, 
//char='/' offset=(0, 5) width=8 height=25 xadvance=7.01563
//.....OWO
//.....OWo
//.....WW.
//....oWW.
//....OWO.
//....OWo.
//....WW..
//...oWW..
//...OWO..
//...OWo..
//...WW...
//..oWW...
//..OWO...
//..WWo...
//..WW....
//.oWW....
//.OWO....
//.WWo....
//.WW.....
//oWW.....
//OWO.....
//WWo.....
//WW......
//WW......
//WO......
0x7800b800, 0x3d003c00, 0x1e002e00, 0xf400f00, 0x7800b80, 0x3d003c0, 0x1f002e0, 0xf400f0, 0x7c00b8, 0x3d003c, 0x1f002e, 0xf000f, 0xb, 
//char='0' offset=(1, 7) width=9 height=18 xadvance=11.1719
//..oWWWo..
//.oWWWWWO.
//.WWO.oWW.
//.WW...WWo
//oWW...OWO
//oWW...OWO
//OWO...OWO
//OWO...OWW
//OWO...OWW
//OWO...OWW
//OWO...OWW
//OWO...OWO
//oWW...OWO
//oWW...OWO
//.WW...WWo
//.WWO.oWW.
//.oWWWWWO.
//..oWWWo..
0xffd01fd0, 0xf0f4bc2, 0xf6e03d7c, 0xae02eb80, 0xe02ef80b, 0x2ef80bb, 0x3db80bbe, 0xcb80f6e0, 0x3d2f1f03, 0x7f40bff4, 0x0, 
//char='1' offset=(1, 7) width=7 height=18 xadvance=11.1719
//....WWo
//...OWWo
//..OWWWo
//.WWWWWo
//.OO.WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
//....WWo
0x7e01f00, 0x287ff1fe, 0xf007c01f, 0x1f007c01, 0x1f007c0, 0xc01f007c, 0x7c01f007, 0x7c01f00, 
//char='2' offset=(1, 7) width=9 height=18 xadvance=11.1719
//.oWWWOo..
//OWWWWWWo.
//.Wo..OWW.
//.....oWW.
//......WW.
//......WW.
//.....OWW.
//.....WWo.
//....OWW..
//...oWW...
//...WWo...
//..OWO....
//.oWW.....
//.OWO.....
//.WWo.....
//oWW......
//oWWWWWWWO
//oWWWWWWWO
0xfff81bf4, 0xf81c1, 0xf0003d, 0xf8003c0, 0x3e001f00, 0x7c003d00, 0xf400b800, 0xc002e000, 0xf4007, 0xfff6fffd, 0xb, 
//char='3' offset=(1, 7) width=9 height=18 xadvance=11.1719
//.OWWWO...
//OWWWWWW..
//.O..oWWO.
//.....oWW.
//.....oWW.
//.....OWW.
//....oWWo.
//..WWWWO..
//..WWWW...
//....oWWo.
//.....oWW.
//......WWo
//......WWo
//......WWo
//......WW.
//oo..oWWW.
//OWWWWWWo.
//.OWWWO...
0xfff80bf8, 0xbd080, 0xf4003d, 0x7d003e0, 0xff00bfc, 0x4001f400, 0x7c000f, 0x7c001f0, 0x3f414f00, 0x2fe07ffe, 0x0, 
//char='4' offset=(1, 7) width=10 height=18 xadvance=11.1719
//.....WWO..
//....oWWO..
//....WWWO..
//...oWWWO..
//...WWoWO..
//..oWOoWO..
//..OW.oWO..
//..WO.oWO..
//.OWo.oWO..
//.WW..oWO..
//oWo..oWO..
//OW...oWO..
//WWWWWWWWWo
//OWWWWWWWWo
//.....oWO..
//.....oWO..
//.....oWO..
//.....oWO..
0xd000bc00, 0xbf000b, 0xb7c00bf4, 0xe00b6d00, 0xb4b00b4, 0x43c0b478, 0xe0b41d0b, 0xffff0b40, 0x7fffe7, 0xb4000b4, 0x4000b400, 0xb, 
//char='5' offset=(1, 7) width=9 height=18 xadvance=11.1719
//..WWWWWW.
//..WWWWWW.
//..WW.....
//..WW.....
//..WW.....
//.oWO.....
//.oWO.....
//.oWWWO...
//.oOWWWW..
//.....WWW.
//......WW.
//......WWo
//......WWo
//......WWo
//.....oWW.
//.o..oWWO.
//oWWWWWW..
//.OWWWO...
0xffc0fff0, 0x3c000f03, 0xd000f000, 0xb4002, 0x3fe402fd, 0x3f000, 0x7c000f, 0x7c001f0, 0x2f410f40, 0x2fe03ffd, 0x0, 
//char='6' offset=(1, 7) width=9 height=18 xadvance=11.1719
//.....OWW.
//...oWWWO.
//..oWWo...
//..WW.....
//.oWO.....
//.OWo.....
//.WWOOOO..
//.WWWWWWO.
//oWWo.oWWo
//oWW...OWO
//oWW...oWW
//oWW...oWW
//oWW...oWW
//.WW...oWW
//.WWo..OWO
//.OWO..WWo
//..WWWWWW.
//...OWWO..
0xfd00f800, 0x3c007d02, 0xe000b400, 0x2abc001, 0xf47d2fff, 0x3db80f5, 0x3df40f7d, 0xcf40f3d0, 0x7c2e2e07, 0xbe00fff0, 0x0, 
//char='7' offset=(1, 7) width=9 height=18 xadvance=11.1719
//WWWWWWWWW
//WWWWWWWWW
//......WWo
//.....oWW.
//.....WWo.
//.....WW..
//....OWO..
//....WWo..
//....WW...
//...oWO...
//...OWo...
//...WWo...
//...WW....
//..oWW....
//..OWO....
//..OWo....
//..WWo....
//..WWo....
0xffffffff, 0x1f000f, 0x7c003d, 0x2e000f0, 0xf0007c0, 0x78002d00, 0xc001f000, 0xf4003, 0x78002e, 0x7c001f0, 0x0, 
//char='8' offset=(1, 7) width=9 height=18 xadvance=11.1719
//..oWWWO..
//.oWWWWWW.
//.WWo..WWo
//oWW...OWO
//oWW...OWO
//oWW...OWo
//.WWo..WW.
//.oWWoOWo.
//..oWWWO..
//..WWWWW..
//.WWo.OWW.
//oWW...WWO
//OWO...oWW
//OWo...oWW
//OWO...oWW
//oWW...WWo
//.OWWWWWW.
//..oWWWO..
0xffd02fd0, 0xf5f07c3, 0xf6e03db8, 0xf07c780, 0x2fd01e7d, 0x87c0ffc0, 0x2ebc0f4f, 0xef407bd0, 0x7c0f7d02, 0xbf40fff8, 0x0, 
//char='9' offset=(1, 7) width=9 height=18 xadvance=11.1719
//..oWWWo..
//.oWWWWWO.
//.WWo.oWW.
//oWW...WWo
//oWW...OWO
//oWO...oWO
//oWW...oWO
//oWW...oWW
//.WWO..OWW
//.oWWWWWWO
//..oWWWWWO
//......WWo
//......WW.
//.....oWW.
//.....WWo.
//...oWWO..
//.OWWWO...
//.OWOo....
0xffd01fd0, 0xf4f47c2, 0xb6e03d7c, 0x6d03db40, 0xe0bcf40f, 0xfd0bffd3, 0x7c002f, 0x3d000f0, 0xbd007c0, 0x6e00bf8, 0x0, 
//char=':' offset=(1, 11) width=4 height=14 xadvance=6.03125
//.WW.
//oWWO
//.WW.
//....
//....
//....
//....
//....
//....
//....
//....
//.WW.
//oWWO
//.WW.
0x3cbd3c, 0x0, 0x3c000000, 0x3cbd, 
//char=';' offset=(0, 11) width=5 height=19 xadvance=6.03125
//..WW.
//.oWWO
//..WW.
//.....
//.....
//.....
//.....
//.....
//.....
//.....
//.....
//.oWW.
//.oWW.
//.oWW.
//.oWO.
//.OWo.
//.WW..
//.WO..
//.....
0xf0bd0f0, 0x0, 0x0, 0xf43d0000, 0x1e0b43d0, 0xb03c, 
//char='<' offset=(1, 11) width=9 height=12 xadvance=11.1719
//.........
//......oWo
//.....OWWO
//...oWWWo.
//.oWWWo...
//OWWO.....
//WWO......
//oWWWo....
//..OWWW...
//....OWWO.
//.....oWWO
//.......Oo
0x40000000, 0xd02f8007, 0xf807f41f, 0x4002f002, 0xfe0007f, 0x4002f800, 0x60002f, 
//char='=' offset=(1, 14) width=10 height=7 xadvance=11.1719
//WWWWWWWWW.
//WWWWWWWWW.
//..........
//..........
//..........
//OWWWWWWWW.
//WWWWWWWWW.
0xfff3ffff, 0x3f, 0x0, 0xff3fffe0, 0x3ff, 
//char='>' offset=(1, 11) width=9 height=12 xadvance=11.1719
//.........
//oWo......
//oWWW.....
//..WWWO...
//...oWWWo.
//.....OWWO
//......OWW
//....oWWWo
//...OWWO..
//.OWWWo...
//OWWO.....
//.O.......
0x740000, 0xfc000fd0, 0x7f4002, 0x3e000be0, 0x2f807f40, 0xbe01fe0, 0x200, 
//char='?' offset=(0, 7) width=9 height=18 xadvance=8.89063
//.oWWWWo..
//.WWWWWWO.
//.o...WWW.
//.....oWWo
//.....oWWo
//.....oWW.
//.....WWo.
//....WWO..
//...OWW...
//...WW....
//..oWO....
//..oWO....
//.........
//.........
//.........
//..oWW....
//..WWW....
//..oWO....
0xfff01ff4, 0xfc042, 0x1f4007d, 0x7c003d0, 0xf800bc0, 0x2d000f00, 0xb400, 0x0, 0xf40000, 0xb4003f0, 0x0, 
//char='@' offset=(1, 7) width=19 height=21 xadvance=21.4219
//......oOWWWWOo.....
//....oWWWWWWWWWWo...
//...OWWOo....oOWWo..
//..oWWo........oWW..
//..WWo...OWWWO..OWO.
//.oWW...WWWWWWO..WW.
//.WWo..OWO..OWO..OWo
//.WW...WW...OWO..oWO
//.WW..oWW...OWO..oWO
//oWW..oWW...OWO..oWO
//oWO..oWW...OWO..oWO
//oWO..oWW...OWO..oWO
//.WW...WW...OWO..OWo
//.WW...WWO..OWO..WW.
//.WWo..oWWWWWWWWWWO.
//.OWO...oWWWooWWWO..
//..WWo..............
//..OWWo.............
//...OWWO............
//....OWWWWWWWW......
//......oOWWWWO......
0x6ff9000, 0xffff4000, 0x6f8001f, 0x1f401f90, 0xf00f4000, 0xb82fe01, 0xc2fff03d, 0xb82e07c3, 0x3c0f1e0, 0xf43cb42e, 0xf6d0b80, 0xdb42e03d, 0xd0b80f42, 0x2e03d0b6, 0x80f03cb4, 0xbc0f1e0b, 0x7c3c2e0, 0xe0bffffd, 0xbf5fd02, 0x1f0, 0x1f800, 0x2f80000, 0xf8000000, 0xfff, 0x2ff90, 
//char='A' offset=(0, 7) width=13 height=18 xadvance=13.0625
//.....WWW.....
//.....WWWo....
//....oWWWO....
//....WWoWW....
//....WW.WW....
//...oWO.OWo...
//...OWo.oWO...
//...WW...WW...
//..oWO...OWo..
//..oWo...OWO..
//..OWo...oWW..
//..WWWWWWWWW..
//.oWWWWWWWWWo.
//.oWO.....OWO.
//.OWo.....oWW.
//.WW.......WW.
//.WW.......WW.
//oWW.......WWo
0xfc00, 0xd00007f0, 0xf7c0002f, 0x3cf0000, 0x1e2d00, 0xf000b478, 0x2d003c0, 0xb807401e, 0x3d01e00, 0xf40ffffc, 0x2d07fff, 0x400782e0, 0x3c000f0f, 0xf4f0003c, 0x7c000, 
//char='B' offset=(2, 7) width=11 height=18 xadvance=13.5313
//OWWWWWOo...
//WWWWWWWWO..
//WWO...OWWo.
//WWO....WWO.
//WWO....OWO.
//WWO....WWO.
//WWO...OWW..
//WWWWWWWWo..
//WWWWWWWWo..
//WWO...OWWo.
//WWO....OWW.
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO....oWW.
//WWO...oWWO.
//WWWWWWWWW..
//OOWWWWOo...
0xffc06ffe, 0x7e02f0bf, 0x2f2f00bc, 0xf00bcb80, 0xfc3e02f2, 0xffff07ff, 0xf1f80bc1, 0xbcf802, 0xdf002f7c, 0x2f7c00b, 0x2f40bcf4, 0xfe83ffff, 0x1b, 
//char='C' offset=(1, 7) width=11 height=18 xadvance=12.1875
//....OWWWWo.
//..oWWWWWWWo
//..WWWo..oO.
//.OWW.......
//.WWO.......
//oWW........
//oWW........
//oWW........
//OWW........
//OWW........
//oWW........
//oWW........
//.WWo.......
//.WWO.......
//.OWW.......
//..WWWo...Oo
//...WWWWWWWO
//....OWWWWO.
0xf407fe00, 0x907f07ff, 0xbc0003e0, 0xf4000, 0xf40003d0, 0x3e0000, 0xd0000f80, 0xf40003, 0x7c00, 0xf80002f, 0x601fc000, 0x802fffc0, 0x2ff, 
//char='D' offset=(2, 7) width=12 height=18 xadvance=14.9688
//oOWWWWOo....
//WWWWWWWWO...
//WWO..oOWWW..
//WWo....oWWo.
//WWo.....OWW.
//WWo.....oWW.
//WWo......WWo
//WWo......WWo
//WWo......WWO
//WWo......WWO
//WWo......WWo
//WWo......WWo
//WWo.....oWW.
//WWo.....OWW.
//WWo....oWWo.
//WWO..oOWWW..
//WWWWWWWWO...
//OOWWWWOo....
0xff006ff9, 0xe42f02ff, 0x1f401f0f, 0x1f3e001f, 0x1f3d00, 0x7c001f7c, 0x1fbc001f, 0x1fbc00, 0x7c001f7c, 0x1f3d001f, 0x401f3e00, 0xfe42f1f, 0xfa02ffff, 0x6f, 
//char='E' offset=(2, 7) width=9 height=18 xadvance=11.8438
//WWWWWWWWo
//WWWWWWWWo
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWO.
//WWWWWWWO.
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWWO
//WWWWWWWWO
0xfffdffff, 0xbc002f7, 0xbc002f00, 0xc002f000, 0xbfff000b, 0x2f2fffc, 0x2f000bc0, 0xf000bc00, 0xbc002, 0xfffeffff, 0xb, 
//char='F' offset=(2, 7) width=9 height=18 xadvance=11.0625
//WWWWWWWWo
//WWWWWWWWo
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWO.
//WWWWWWWO.
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
0xfffdffff, 0xbc002f7, 0xbc002f00, 0xc002f000, 0xbfff000b, 0x2f2fffc, 0x2f000bc0, 0xf000bc00, 0xbc002, 0xbc002f, 0x0, 
//char='G' offset=(1, 7) width=11 height=18 xadvance=13.6406
//....OWWWWO.
//..oWWWWWWWO
//..WWWo..oOo
//.OWW.......
//.WWO.......
//.WWo.......
//oWW........
//oWW........
//OWW........
//OWW.....oWO
//oWW.....oWW
//oWW.....oWW
//.WWo....oWW
//.WWO....oWW
//.OWWo...oWW
//..WWWo..OWW
//...WWWWWWWW
//....OWWWWOo
0xf40bfe00, 0x907f0bff, 0xbc0003e1, 0x1f0000, 0xf40003d0, 0x3e0000, 0xdb400f80, 0xf7d003, 0x3d007cf4, 0x1f8f402f, 0xf81fc3d0, 0x803fffc0, 0x6ff, 
//char='H' offset=(2, 7) width=11 height=18 xadvance=14.9688
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWWWWWWWWWW
//WWWWWWWWWWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
0xbfe002f, 0xe002ff80, 0x2ff800bf, 0x800bfe00, 0xbfe002ff, 0xfffff800, 0xffffffff, 0xbfe002, 0xfe002ff8, 0x2ff800b, 0xf800bfe0, 0xbfe002f, 0xf80, 
//char='I' offset=(2, 7) width=3 height=18 xadvance=6.70313
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
//WWO
0xefbefbef, 0xfbefbefb, 0xbefbefbe, 0xbef, 
//char='J' offset=(0, 7) width=9 height=18 xadvance=10.2656
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//......WW.
//.....oWW.
//oO..oWWW.
//OWWWWWWo.
//.OWWWO...
0xc000f000, 0xf0003, 0xf0003c, 0xf0003c0, 0xf0003c00, 0x3c000, 0x3c000f, 0x3c000f0, 0x3f424f40, 0x2fe07ffe, 0x0, 
//char='K' offset=(2, 7) width=12 height=18 xadvance=13.375
//WWO....oWW..
//WWO....WWo..
//WWO...OWW...
//WWO..oWW....
//WWO..WWo....
//WWO.OWO.....
//WWOoWW......
//WWOWWo......
//WWWWW.......
//WWWWWO......
//WWOoWWO.....
//WWO.OWWo....
//WWO..OWW....
//WWO...WWO...
//WWO...oWWo..
//WWO....WWW..
//WWO....oWWo.
//WWO.....OWW.
0x2f0f402f, 0xe02f07c0, 0xf42f03, 0x2f007c2f, 0xf6f002e, 0x7ef00, 0xff0003ff, 0x2f6f000b, 0x7e2f00, 0x2f00f82f, 0xd02f02f0, 0xfc02f07, 0x2f1f402f, 0x3e00, 
//char='L' offset=(2, 7) width=9 height=18 xadvance=10.8281
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWW.
//WWWWWWWW.
0xbc002f, 0xbc002f0, 0xbc002f00, 0xc002f000, 0x2f000b, 0x2f000bc, 0x2f000bc0, 0xf000bc00, 0xbc002, 0xfffcffff, 0x3, 
//char='M' offset=(1, 7) width=17 height=18 xadvance=18.875
//.oWWo.......oWW..
//.oWWO.......WWWo.
//.oWWW.......WWWo.
//.OWWWo.....OWWWo.
//.OWOWW.....WWOWo.
//.OWoWW....oWOOWO.
//.OWooWO...OWooWO.
//.WWo.WW...WW.oWO.
//.WWo.OW..oWO.oWO.
//.WWo.oWO.OWo.oWO.
//.WW...WW.WW..oWW.
//.WW...OWoWO..oWW.
//.WW...oWWWo..oWW.
//.WW....WWW...oWW.
//.WW....WWO...oWW.
//.WW....ooo....WW.
//.WW...........WW.
//.WW...........WW.
0x3d0001f4, 0xfc000bd0, 0xf0003f41, 0xe001fe07, 0xc00fb81f, 0x403de07b, 0x2d782eb, 0xf1f0b5e, 0x387c2d3c, 0xd1f0b4b4, 0x3c2d1e2, 0xf0f43cf, 0x3c3d0b78, 0xf0f41fd0, 0xc3d03f00, 0xf40bc03, 0x3c01500f, 0xf000003c, 0xc00000f0, 0x3, 
//char='N' offset=(2, 7) width=11 height=18 xadvance=15.0938
//WWo.....oWW
//WWW.....oWW
//WWWO....oWW
//WWWW....oWW
//WWWWO...oWW
//WWoWW...oWW
//WWooWO..oWW
//WWo.WW..oWW
//WWo.oWO.oWW
//WWo..WW.oWW
//WWo..oWOoWW
//WWo...WWoWW
//WWo...oWWWW
//WWo....WWWW
//WWo....oWWW
//WWo.....WWW
//WWo.....OWW
//WWo......WW
0xffd001f, 0xd00bff40, 0xfff403ff, 0x40f7fd02, 0x7fd0b5ff, 0x2d1ff43c, 0xff4f07fd, 0xc07fdb41, 0xffd01ff7, 0x1fff007, 0xfc007ff4, 0x7fe001f, 0xf00, 
//char='O' offset=(1, 7) width=14 height=18 xadvance=15.7188
//....OWWWOo....
//...WWWWWWWO...
//..WWWo..OWWO..
//.oWW.....oWWo.
//.WWO......WWO.
//.WWo......OWW.
//oWW.......oWW.
//oWW.......oWW.
//OWW.......oWWo
//OWW.......oWWo
//oWW.......oWW.
//oWW.......oWW.
//.WWo......OWW.
//.WWO......WWO.
//.OWW.....oWWo.
//..WWWo..oWWO..
//...WWWWWWWO...
//....OWWWWo....
0x6fe00, 0xf002fffc, 0xf40be07, 0xbc1f40, 0x7c2f0, 0xd0003d3e, 0x3d0003d3, 0xe7d0003e, 0x3d7d0003, 0x3d3d000, 0x7c3d00, 0xbc3e0, 0xf400f82f, 0xbd07f01, 0x2fffc0, 0x7fe0, 
//char='P' offset=(2, 7) width=10 height=18 xadvance=12.6094
//OWWWWWO...
//WWWWWWWWo.
//WWO..oWWW.
//WWO....WWo
//WWO....WWO
//WWO....OWO
//WWO....WWO
//WWO...oWWo
//WWO..oWWW.
//WWWWWWWWo.
//WWWWWWO...
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
0xfff02ffe, 0xf3f42f1f, 0xc02f7c02, 0x2fb802fb, 0x7d02fbc0, 0xfff3f42f, 0xf02fff1f, 0x2f0002, 0x2f0002f0, 0x2f000, 0x2f0002f, 0x0, 
//char='Q' offset=(1, 7) width=14 height=23 xadvance=15.7188
//....oWWWOo....
//...WWWWWWWO...
//..WWWo..OWWO..
//.oWWo....oWW..
//.WWO......WWO.
//.WWo......OWW.
//oWW.......oWW.
//oWW.......oWW.
//oWW.......oWWo
//OWW........WWo
//oWW.......oWW.
//oWW.......oWW.
//oWW.......oWW.
//.WWo......OWO.
//.OWW......WWo.
//.oWWO....OWW..
//..OWWOoOWWWo..
//...OWWWWWWo...
//.....oWWO.....
//......OWO.....
//.......WWWo...
//........WWWWo.
//.........oOW..
0x6fd00, 0xf002fffc, 0x1f40be07, 0xbc0f40, 0x7c2f0, 0xd0003d3e, 0x3d0003d3, 0xe7d0003d, 0x3d7c0003, 0x3d3d000, 0x3d3d00, 0x7c3d0, 0xf000f82e, 0xf802f41, 0x7f9be0, 0x1fff8, 0x2f4, 0xc000002e, 0xf000001f, 0xe400001f, 0x0, 
//char='R' offset=(2, 7) width=11 height=18 xadvance=13.3594
//OWWWWWO....
//WWWWWWWWo..
//WWO..oWWW..
//WWo...oWWo.
//WWo....WWO.
//WWo....WWO.
//WWo....WWO.
//WWo...oWWo.
//WWo..oWWW..
//WWWWWWWW...
//WWWWWWW....
//WWo..OWO...
//WWo..oWW...
//WWo...OWO..
//WWo...oWW..
//WWo....WWO.
//WWo....oWW.
//WWo.....WWo
0xffc02ffe, 0x3f42f07f, 0x1f1f407c, 0xf007cbc0, 0x7cbc01f2, 0xf41f1f40, 0xf03fffc3, 0xe07c03ff, 0xc0f41f02, 0x1f0b807, 0x2f007c3d, 0x7cf401f, 0x7c0, 
//char='S' offset=(0, 7) width=10 height=18 xadvance=10.3906
//...oWWWWO.
//..WWWWWWW.
//.OWWo...o.
//.WWO......
//.WWo......
//.WWO......
//.OWW......
//..WWWo....
//...WWWO...
//....OWWW..
//.....oWWW.
//......oWWo
//.......WWO
//.......OWO
//.......WWO
//.Oo...OWWo
//.WWWWWWWO.
//.oOWWWOo..
0xff02ff40, 0xc101f83f, 0x7c000b, 0xf8000bc0, 0x7f0000, 0xe0002fc0, 0x3f4000f, 0xc0007d00, 0xb8000b, 0x7e018bc0, 0xfe42fffc, 0x6, 
//char='T' offset=(0, 7) width=11 height=18 xadvance=11.0625
//OWWWWWWWWWO
//OWWWWWWWWWO
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
0xffaffffe, 0x2e00bff, 0xb800, 0xb80002e, 0x2e000, 0x2e0000b8, 0xb8000, 0xb80002e0, 0x2e0000, 0xe0000b80, 0xb80002, 0x80002e00, 0xb, 
//char='U' offset=(2, 7) width=11 height=18 xadvance=14.2656
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WWo
//WWo.....WW.
//WWO....oWW.
//OWW....OWW.
//oWWO..oWWO.
//.OWWWWWWW..
//..oWWWWO...
0x7df001f, 0xf001f7c0, 0x1f7c007d, 0xc007df00, 0x7df001f7, 0x1f7c00, 0xf7c007df, 0x7df001, 0xcf001f7c, 0x3e3d00b, 0x2f42f4f8, 0xf403fff8, 0x2f, 
//char='V' offset=(0, 7) width=13 height=18 xadvance=12.9219
//oWW.......WWo
//.WWo.....oWW.
//.WWo.....oWW.
//.OWO.....OWO.
//.OWW.....WWo.
//.oWW.....WW..
//..WWo...oWW..
//..WWo...oWO..
//..OWO...OWo..
//..oWW...WW...
//...WW..oWW...
//...OWo.oWO...
//...oWO.OWo...
//....WW.WW....
//....WWOWO....
//....OWWWo....
//....oWWW.....
//.....WWW.....
0xf1f0003d, 0x7c3d001, 0x2e0f40, 0x7c00f82e, 0xf003d0, 0x7c03d01f, 0x2e00b40, 0x3c0f401e, 0xf43c00, 0x4002d1e0, 0x3c00078b, 0x2ef0000f, 0x7f8000, 0xfd00, 0x3f0, 
//char='W' offset=(1, 7) width=18 height=18 xadvance=19.6406
//WWo............OWO
//OWO............WWo
//OWO....oWW.....WWo
//OWO....OWWo....WW.
//oWW....WWWO....WW.
//oWW....WWWO...oWW.
//.WW...oWOWW...oWO.
//.WW...OWoOWo..oWO.
//.WWo..OW.oWo..OWo.
//.OWo..WW..WO..OWo.
//.oWO.oWO..WW..WW..
//.oWW.OWo..OWo.WW..
//..WW.WW...oWO.WO..
//..WW.WO....WWoWO..
//..OWOWo....WWOWo..
//..oWWW.....OWWW...
//...WWW.....oWWW...
//...WWO......WWO...
0x8000001f, 0x2eb, 0xf402e7c, 0xf802e7c0, 0xc03d3c01, 0x3d3c02f, 0x3c3d02fc, 0xc2d03ed0, 0x2d079e03, 0xe074e07c, 0xb0f0781, 0xf0b4b41e, 0x78f40f0, 0x3cf00f1e, 0xcf00b2d0, 0xe00b7c02, 0x7bc01e, 0x3f800fd, 0x3f400fc0, 0xf000bc00, 0x2, 
//char='X' offset=(0, 7) width=12 height=18 xadvance=12.2344
//.WW......WWo
//.OWO....OWO.
//..WW....WWo.
//..OWO..oWW..
//..oWW..WWo..
//...OWOoWW...
//...oWWWWo...
//....OWWW....
//....oWWO....
//....OWWW....
//....WWWWo...
//...OWOoWW...
//...WW..WWo..
//..OWO..oWW..
//..WW....WWo.
//.OWO....OWO.
//.WWo.....WW.
//oWW......OWO
0xb87c003c, 0xf02e00, 0xf42e01f, 0x8007c3d0, 0xff4003db, 0xfe0001, 0xbd00, 0xff0000fe, 0x3db8001, 0xe007c3c0, 0xf00f42, 0x2e00b81f, 0x3d3c007c, 0xb800, 
//char='Y' offset=(0, 7) width=12 height=18 xadvance=11.7188
//OWO......WWo
//oWW.....oWW.
//.WWo....OWO.
//.OWW....WWo.
//..WW...oWW..
//..OWO..WWo..
//..oWW..WW...
//...WWoOWO...
//...oWWWW....
//....WWWO....
//....OWWo....
//....oWW.....
//....oWW.....
//....oWW.....
//....oWW.....
//....oWW.....
//....oWW.....
//....oWW.....
0x3d7c002e, 0x7c3d00, 0x1f00f82e, 0xe00f40f0, 0xc3d007c2, 0x2e7c003, 0xff40, 0x7e0000bf, 0x3d0000, 0x3d00, 0x3d00003d, 0x3d0000, 0x3d00, 0x3d, 
//char='Z' offset=(0, 7) width=11 height=18 xadvance=11.2188
//.WWWWWWWWW.
//.WWWWWWWWW.
//.......OWO.
//.......WW..
//......OWO..
//......WW...
//.....OWO...
//.....WW....
//....OWO....
//....WW.....
//...OWO.....
//...WWo.....
//..OWW......
//..WWo......
//.oWW.......
//.OWo.......
//.WWWWWWWWWo
//.WWWWWWWWWo
0xff0ffffc, 0xb80003ff, 0xf0000, 0x3c0002e0, 0xb8000, 0x2e0000f0, 0x3c000, 0x1f0000b8, 0x3e000, 0xf40007c, 0x1e000, 0xff1ffffc, 0x7ff, 
//char='[' offset=(2, 5) width=6 height=25 xadvance=7.29688
//OWWWW.
//OWWOO.
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWO...
//OWWOO.
//OWWWW.
0x2e2be3fe, 0xe02e02e0, 0x2e02e02, 0x2e02e02e, 0xe02e02e0, 0x2e02e02, 0x2e02e02e, 0xe02e02e0, 0x2be02e02, 0x3fe, 
//char='\' offset=(0, 5) width=8 height=25 xadvance=7.01563
//WO......
//WW......
//WW......
//WWo.....
//OWO.....
//oWW.....
//.WW.....
//.WWo....
//.OWO....
//.oWW....
//..WW....
//..WWo...
//..OWO...
//..oWW...
//...WW...
//...OWo..
//...OWO..
//...oWW..
//....WW..
//....OWo.
//....OWO.
//....oWW.
//.....WW.
//.....OWo
//.....OWO
0xf000b, 0x1f000f, 0x3d002e, 0x7c003c, 0xf400b8, 0x1f000f0, 0x3d002e0, 0x78003c0, 0xf400b80, 0x1e000f00, 0x3d002e00, 0x78003c00, 0xb800, 
//char=']' offset=(0, 5) width=5 height=25 xadvance=7.29688
//WWWWW
//OOWWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//..oWW
//OOWWW
//WWWWW
0x3d0febff, 0xf43d0f4, 0x43d0f43d, 0xd0f43d0f, 0xf43d0f43, 0x3d0f43d0, 0xf43d0f4, 0x3fffebd, 
//char='^' offset=(0, 7) width=11 height=10 xadvance=11.1719
//....OWW....
//....WWWo...
//...OWWWO...
//...WWoWW...
//..oWW.OWO..
//..OWo..WW..
//..WW...WWo.
//.OWO...oWO.
//.WW.....WW.
//.oO.....OO.
0xc0003e00, 0xbf8001f, 0xd003df00, 0xf07802e3, 0xe07c0f00, 0x3c2d02, 0x280090f, 
//char='_' offset=(0, 28) width=10 height=2 xadvance=9.53125
//WWWWWWWWWO
//WWWWWWWWWO
0xfffbffff, 0xbf, 
//char='`' offset=(0, 4) width=6 height=6 xadvance=8.15625
//......
//.OW...
//.WWO..
//..WWo.
//...WW.
//....O.
0xbc038000, 0x3c01f00, 0x20, 
//char='a' offset=(1, 11) width=9 height=14 xadvance=11.2813
//.oOWWWo..
//.OWWWWWO.
//.....OWW.
//......WWo
//......OWo
//..oOWOWWo
//.WWWWWWWo
//OWWo..WWo
//WWo...OWo
//WWo...OWo
//WWo...OWo
//OWW...WWo
//.WWWWWWWo
//..OWWWWO.
0xffe01fe4, 0xf8002, 0x41e0007c, 0x9fffc7ee, 0xe01f7c1f, 0x1f7807d, 0xfc7c0f9e, 0x2ff81ff, 
//char='b' offset=(2, 4) width=9 height=21 xadvance=12.1406
//.........
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWOWWWo..
//WWWWWWWo.
//WWo..OWW.
//WWo...WWo
//WWo...OWO
//WWo...OWW
//WWo...oWW
//WWo...oWW
//WWo...OWW
//WWo...OWO
//WWo...WWo
//WWo..OWW.
//WWWWWWWo.
//oOWWWOo..
0x7c0000, 0x7c001f0, 0x7c001f00, 0xc001f000, 0x7fff07fb, 0x1f3e07c, 0x1fb807df, 0xff407fe0, 0xf807fd01, 0xc07ee01f, 0xffcf81f7, 0x1bf91f, 
//char='c' offset=(1, 11) width=8 height=14 xadvance=9.17188
//...OWWWo
//..WWWWWo
//.WWW....
//oWW.....
//OWW.....
//OWO.....
//OWO.....
//OWO.....
//OWO.....
//OWW.....
//oWW.....
//.WWW....
//.oWWWWWO
//...OWWWo
0x7ff07f80, 0x3d00fc, 0x2e003e, 0x2e002e, 0x3e002e, 0xfc003d, 0x7f80bff4, 
//char='d' offset=(1, 4) width=10 height=21 xadvance=12.1406
//..........
//.......WW.
//.......WW.
//.......WW.
//.......WW.
//.......WW.
//.......WW.
//..oOWWOWW.
//.oWWWWWWW.
//.WWO..oWW.
//oWW....WW.
//OWW....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWW....WW.
//oWW....WW.
//.WWW...WW.
//.oWWWWWWW.
//...OWWWOo.
0x0, 0x3c0003c, 0xc0003c00, 0x3c0003, 0x3ef903c0, 0xbc3fff4, 0xe3c03d3d, 0xc02e3c03, 0x2e3c02e3, 0x3c02e3c0, 0x3d3c03e, 0x43c0fc3c, 0xbf803fff, 0x1, 
//char='e' offset=(1, 11) width=10 height=14 xadvance=11.3281
//..oOWWO...
//.oWWWWWW..
//.WWO..WWo.
//oWW...OWO.
//oWO...oWW.
//OWO...oWW.
//OWWWWWWWW.
//OWWWWWWWW.
//OWO.......
//oWW.......
//oWW.......
//.WWW...o..
//.oWWWWWWo.
//...OWWWO..
0xff402f90, 0xd1f0bc0f, 0xd02d2e03, 0xfe3d02e3, 0x3fffe3ff, 0x3d0002e, 0xc0003d00, 0xfff4040f, 0xbf801, 
//char='f' offset=(2, 5) width=7 height=20 xadvance=7.95313
//.oOWWO.
//.WWWWW.
//OWO....
//WWo....
//WWo....
//WWo....
//WWWWWW.
//WWWWWO.
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
0xe3ff0be4, 0x1f007c02, 0xfff007c0, 0xc01f2ffc, 0x7c01f007, 0x7c01f00, 0x7c01f0, 0xf007c01f, 0x7c01, 
//char='g' offset=(1, 11) width=10 height=19 xadvance=12.1406
//...OWWWOo.
//..WWWWWWW.
//.WWW...WW.
//.WW....WW.
//oWW....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//oWW....WW.
//.WWO..oWW.
//.oWWWWWWW.
//..oOWWOWW.
//.......WW.
//......oWW.
//......WWO.
//.OWWWWWW..
//.oOWWWO...
0xff01bf80, 0xc3c0fc3f, 0xc03d3c03, 0x2e3c02e3, 0x3c02e3c0, 0x2e3c02e, 0xc3c03d3c, 0xfff43d0b, 0x3ef903, 0x3d0003c0, 0xff82f000, 0x2fe40f, 
//char='h' offset=(2, 4) width=9 height=21 xadvance=12.5313
//.........
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWWWWWO..
//WWWWWWWO.
//WWo..OWW.
//WWo...WWo
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
0x7c0000, 0x7c001f0, 0x7c001f00, 0xc001f000, 0xbfff0bff, 0x1f3e07c, 0x1fb807df, 0xfb807ee0, 0xb807ee01, 0x807ee01f, 0x7ee01fb, 0x2e01fb8, 
//char='i' offset=(1, 6) width=4 height=19 xadvance=6.28125
//.WW.
//oWWO
//.OW.
//....
//....
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
//.WWo
0x38bd3c, 0x7c7c7c00, 0x7c7c7c7c, 0x7c7c7c7c, 0x7c7c7c, 
//char='j' offset=(0, 6) width=5 height=24 xadvance=6.28125
//..OW.
//.oWWO
//..WWo
//.....
//.....
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WWo
//..WW.
//.OWW.
//WWWO.
//WWo..
0x1f0bd0e0, 0x7c00000, 0xc1f07c1f, 0xf07c1f07, 0x7c1f07c1, 0x1f07c1f0, 0xf3e0f07c, 0x7cb, 
//char='k' offset=(2, 4) width=9 height=21 xadvance=11.0938
//.o.......
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWo...WW.
//WWo..OWO.
//WWo.oWW..
//WWo.WWo..
//WWoOWO...
//WWOWW....
//WWWWO....
//WWOWW....
//WWoOWW...
//WWo.WWO..
//WWo.oWW..
//WWo..WWO.
//WWo..oWW.
//WWo...OWO
0x7c0004, 0x7c001f0, 0x7c001f00, 0xc001f000, 0xb81f3c07, 0xf1f0f47c, 0xef02e7c1, 0xf00bfc03, 0x3e7c03e, 0xf47c2f1f, 0x7cbc1f0, 0x2e01f3d, 
//char='l' offset=(1, 4) width=5 height=21 xadvance=6.3125
//..o..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WW..
//.WWo.
//.WWO.
//.OWWO
//..OWO
0x3c0f010, 0xc0f03c0f, 0xf03c0f03, 0x3c0f03c0, 0xf03c0f0, 0xbc1f03c, 0x2e0be, 
//char='m' offset=(2, 11) width=15 height=14 xadvance=18.1406
//oOWWWOooOWWWo..
//WWWWWWWWWWWWWo.
//WWo..WWWo..OWW.
//WWo..oWW....WW.
//WWo...WW....WW.
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
//WWo...WWo...WWo
0xc1fe5bf9, 0xf1ffffff, 0x7cf81fc1, 0x1f3c03d0, 0x7cf00f0, 0x1f7c07c, 0xc07df01f, 0xf01f7c07, 0x7c07df01, 0x1f01f7c0, 0x7c07df0, 0x1f01f7c, 0xc07c07df, 0x7, 
//char='n' offset=(2, 11) width=9 height=14 xadvance=12.5313
//oOWWWWo..
//WWWWWWWO.
//WWo..OWW.
//WWo...WWo
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
0xfffc1ff9, 0x7cf81f2, 0x7ee01f7c, 0xee01fb80, 0xe01fb807, 0x1fb807e, 0x1fb807ee, 0xb807ee0, 
//char='o' offset=(1, 11) width=10 height=14 xadvance=12.0313
//...OWWOo..
//.oWWWWWWo.
//.WWO..OWW.
//oWW....WWo
//OWW....WWO
//OWO....OWO
//OWO....OWO
//OWO....OWO
//OWO....OWO
//OWW....WWO
//oWW....WWo
//.WWO..OWW.
//.oWWWWWWo.
//...OWWOo..
0xff406f80, 0xd3e0bc1f, 0xc03e7c03, 0x2eb802eb, 0xb802eb80, 0x3eb802e, 0xc7c03dbc, 0xfff43e0b, 0x6f801, 
//char='p' offset=(2, 11) width=9 height=19 xadvance=12.1406
//oOWWWO...
//WWWWWWWo.
//WWo..OWW.
//WWo...WWo
//WWo...OWO
//WWo...OWW
//WWo...oWW
//WWo...oWW
//WWo...OWW
//WWo...OWO
//WWo...WWo
//WWo..OWW.
//WWWWWWWO.
//WWOWWWo..
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
0xfffc0bf9, 0x7cf81f1, 0x7ee01f7c, 0xfd01ff80, 0xe01ff407, 0x1fb807f, 0xff3e07df, 0xf07fbcbf, 0x7c001, 0x7c001f, 0x1f0, 
//char='q' offset=(1, 11) width=10 height=19 xadvance=12.1406
//...OWWWOo.
//..WWWWWWW.
//.WWW...WW.
//oWW....WW.
//OWW....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWO....WW.
//OWW....WW.
//oWW....WW.
//.WWO..oWW.
//.oWWWWWWW.
//..oWWWOWW.
//.......WW.
//.......WW.
//.......WW.
//.......WW.
//.......WW.
0xff01bf80, 0xd3c0fc3f, 0xc03e3c03, 0x2e3c02e3, 0x3c02e3c0, 0x3e3c02e, 0xc3c03d3c, 0xfff43d0b, 0x3efd03, 0x3c0003c0, 0x3c000, 0x3c0003c, 
//char='r' offset=(2, 11) width=7 height=14 xadvance=8.51563
//oOWWWW.
//WWWWWW.
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
0xf3ffcff9, 0x1f007c01, 0x1f007c0, 0xc01f007c, 0x7c01f007, 0x7c01f00, 0x0, 
//char='s' offset=(0, 11) width=9 height=14 xadvance=8.85938
//...OWWOo.
//..WWWWWo.
//.OWW.....
//.OWo.....
//.OWO.....
//.oWWo....
//..OWWO...
//...oWWW..
//.....OWW.
//......WW.
//......WW.
//.o...OWW.
//.WWWWWWo.
//.oWWWWo..
0xffc06f80, 0x1e000f81, 0xd000b800, 0xbe0007, 0xf8000fd0, 0x3c000, 0xfc3e010f, 0x7fd07f, 
//char='t' offset=(1, 6) width=7 height=19 xadvance=8.34375
//.......
//.OW....
//.WW....
//.WW....
//.WW....
//.WWWWWO
//.WWWWWO
//.WW....
//.WW....
//.WW....
//.WW....
//.WW....
//.WW....
//.WW....
//.WW....
//.WW....
//.WWO...
//.oWWWWO
//..oWWWO
0xc00e0000, 0x3c00f003, 0xffcbff00, 0x3c00f2, 0xf003c00f, 0xf003c00, 0xf003c0, 0xbfd00bc, 0x2fd, 
//char='u' offset=(1, 11) width=10 height=14 xadvance=12.4688
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WW....OWo
//.WWo...OWo
//.OWW...WWo
//..WWWWWWWo
//...OWWWWO.
0x3c7803c, 0xc7803c78, 0x803c7803, 0x3c7803c7, 0x7803c780, 0x3c7803c, 0x87807c78, 0xfff07c0f, 0x2ff807, 
//char='v' offset=(0, 11) width=10 height=14 xadvance=10.3125
//oWW....oWW
//oWW....OWO
//.WW....OWo
//.WWo...WW.
//.OWO...WW.
//.oWW..oWO.
//..WW..OWo.
//..WWo.WW..
//..OWO.WW..
//..oWOoWO..
//...WWOWo..
//...WWWW...
//...oWWW...
//....WWo...
0x3df403d, 0xc7803cb8, 0xc0b83c07, 0xf02d0f43, 0xf1f01e0, 0x6d00f2e0, 0x7bc00b, 0x3f4003fc, 0x1f000, 
//char='w' offset=(0, 11) width=15 height=14 xadvance=14.8906
//oWO...oWO...WWo
//oWW...OWW...WW.
//.WW...WWW...WW.
//.WW...WWW...WW.
//.OWo..WOWo.oWO.
//.OWo.oWoWo.oWo.
//.oWO.OW.WO.OWo.
//..WO.OW.WO.WW..
//..WW.WO.OW.WW..
//..OW.WO.OWoWO..
//..OWOWo.oWOWo..
//..oWWW...WWW...
//...WWW...WWW...
//...OWO...OWO...
0x5f02d02d, 0xc3c0f80f, 0xf0f03f03, 0x783c0fc0, 0x1e0b47b0, 0x8b41d1dd, 0xe2c078b3, 0x2cf00f2c, 0x8b3803ce, 0xd1ee00b7, 0xf03f401e, 0xfc0fc003, 0x2e02e000, 0x0, 
//char='x' offset=(0, 11) width=10 height=14 xadvance=10.1875
//oWW....OWo
//.OWO..oWW.
//..WW..OWo.
//..OWooWW..
//...WWWWo..
//...OWWW...
//...oWWo...
//...OWWW...
//...WWWWo..
//..OWooWW..
//..WW..WWo.
//.OWO..oWO.
//.WW....WW.
//oWO....OWO
0xb87803d, 0x1e0f03d, 0x7fc00f5e, 0x4003f800, 0x3f8001f, 0x5e007fc0, 0x81f0f00f, 0xc03c2d0b, 0xb802d3, 
//char='y' offset=(0, 11) width=10 height=19 xadvance=10.2813
//OWW....oWW
//oWW....OWO
//.WW....OWo
//.WWo...WW.
//.OWO...WW.
//.oWW..oWO.
//..WW..OWo.
//..WWo.WW..
//..OWO.WW..
//..oWWoWO..
//...WWWWo..
//...WWWW...
//...oWWO...
//....WWo...
//....WW....
//...oWO....
//...WW.....
//OWWWO.....
//OWWO......
0x3df403e, 0xc7803cb8, 0xc0b83c07, 0xf02d0f43, 0xf1f01e0, 0x7d00f2e0, 0x7fc00b, 0x2f4003fc, 0x1f000, 0xb4000f, 0x2fe003c0, 0xbe00, 
//char='z' offset=(0, 11) width=9 height=14 xadvance=9.25
//.WWWWWWWo
//.OWWWWWWo
//.....oWW.
//.....WWo.
//....OWO..
//....WWo..
//...OWO...
//...WWo...
//..oWO....
//..WWo....
//.oWW.....
//.WWo.....
//.WWWWWWWo
//.WWWWWWWo
0xffe1fffc, 0xf4007, 0x2e001f, 0xb8007c, 0x2d001f0, 0xf4007c0, 0xfc001f00, 0x7fff1ff, 
//char='{' offset=(0, 5) width=7 height=25 xadvance=6.90625
//....OWO
//...OWWO
//...WW..
//..oWW..
//..oWW..
//..oWW..
//..oWW..
//..oWW..
//..oWO..
//..oWO..
//..OWo..
//.OWW...
//.WWo...
//.OWW...
//..OWo..
//..oWO..
//..oWO..
//..oWW..
//..oWW..
//..oWW..
//..oWW..
//..oWW..
//...WW..
//...OWWO
//....OWO
0xbe02e00, 0xd00f403c, 0x3d00f403, 0x2d00f40, 0xe01e00b4, 0x3e007c03, 0xb401e00, 0xf402d0, 0xd00f403d, 0x3c00f403, 0x2e00be00, 
//char='|' offset=(2, 5) width=3 height=25 xadvance=6.98438
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
//OWO
0xaebaebae, 0xebaebaeb, 0xbaebaeba, 0xaebaebae, 0x2ebaeb, 
//char='}' offset=(0, 5) width=6 height=25 xadvance=6.90625
//WWo...
//OWWO..
//.oWW..
//..WW..
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..OWO.
//...WWO
//...oWW
//...WWO
//..OWO.
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..WWo.
//..WW..
//.oWW..
//OWWO..
//WWo...
0xf40be01f, 0x1f00f00, 0x1f01f01f, 0xe01f01f0, 0xf40bc02, 0x1f02e0bc, 0xf01f01f0, 0x1f01f01, 0xbe0f40f, 0x1f, 
//char='А' offset=(0, 7) width=13 height=18 xadvance=13.0625
//.....WWW.....
//.....WWWo....
//....oWWWO....
//....WWoWW....
//....WW.WW....
//...oWO.OWo...
//...OWo.oWO...
//...WW...WW...
//..oWO...OWo..
//..oWo...OWO..
//..OWo...oWW..
//..WWWWWWWWW..
//.oWWWWWWWWWo.
//.oWO.....OWO.
//.OWo.....oWW.
//.WW.......WW.
//.WW.......WW.
//oWW.......WWo
0xfc00, 0xd00007f0, 0xf7c0002f, 0x3cf0000, 0x1e2d00, 0xf000b478, 0x2d003c0, 0xb807401e, 0x3d01e00, 0xf40ffffc, 0x2d07fff, 0x400782e0, 0x3c000f0f, 0xf4f0003c, 0x7c000, 
//char='Б' offset=(2, 7) width=10 height=18 xadvance=13.0156
//WWWWWWWWo.
//WWWWWWWWo.
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWWWWWO...
//WWWWWWWWo.
//WWO..oWWW.
//WWO....WWo
//WWO....OWO
//WWO....OWW
//WWO....OWW
//WWO....OWO
//WWO....WWo
//WWO..oWWW.
//WWWWWWWWo.
//OWWWWWO...
0xfff1ffff, 0xf0002f1f, 0x2f0002, 0xff0002f0, 0x1ffff02f, 0x2f3f42f, 0xfb802f7c, 0x802ff802, 0x2fb802ff, 0x3f42f7c0, 0xffe1ffff, 0x2, 
//char='В' offset=(2, 7) width=11 height=18 xadvance=13.5313
//OWWWWWOo...
//WWWWWWWWO..
//WWO...OWWo.
//WWO....WWO.
//WWO....OWO.
//WWO....WWO.
//WWO...OWW..
//WWWWWWWWo..
//WWWWWWWWo..
//WWO...OWWo.
//WWO....OWW.
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO....oWW.
//WWO...oWWO.
//WWWWWWWWW..
//OOWWWWOo...
0xffc06ffe, 0x7e02f0bf, 0x2f2f00bc, 0xf00bcb80, 0xfc3e02f2, 0xffff07ff, 0xf1f80bc1, 0xbcf802, 0xdf002f7c, 0x2f7c00b, 0x2f40bcf4, 0xfe83ffff, 0x1b, 
//char='Г' offset=(2, 7) width=9 height=18 xadvance=10.6563
//WWWWWWWW.
//WWWWWWWW.
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
0xfffcffff, 0xbc002f3, 0xbc002f00, 0xc002f000, 0x2f000b, 0x2f000bc, 0x2f000bc0, 0xf000bc00, 0xbc002, 0xbc002f, 0x0, 
//char='Д' offset=(0, 7) width=15 height=23 xadvance=15.0938
//....OWWWWWWWO..
//....OWWWWWWWO..
//....OWO...OWO..
//....OWO...OWO..
//....OWO...OWO..
//....WWO...OWO..
//....WWo...OWO..
//....WWo...OWO..
//....WWo...OWO..
//....WW....OWO..
//...oWW....OWO..
//...OWW....OWO..
//...WWO....OWO..
//...WWo....OWO..
//..OWW.....OWO..
//..WWO.....OWO..
//WWWWWWWWWWWWWWo
//WWWWWWWWWWWWWWo
//WWo.........WWo
//WWo.........WWo
//WWo.........WWo
//WWo.........WWo
//WWo.........WWo
0x2fffe00, 0xbfff80, 0x2e02e0, 0xb80b8, 0xc002e02e, 0xf000b80b, 0x7c002e01, 0x1f000b80, 0x3c002e0, 0xf400b8, 0x803e002e, 0xe00bc00b, 0xb801f002, 0x2e003e00, 0xb800bc0, 0xdfffffff, 0xf7ffffff, 0x7df00001, 0x1f7c0000, 0x7df0000, 0x1f7c000, 0x1f000, 
//char='Е' offset=(2, 7) width=9 height=18 xadvance=11.8438
//WWWWWWWWo
//WWWWWWWWo
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWO.
//WWWWWWWO.
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWO......
//WWWWWWWWO
//WWWWWWWWO
0xfffdffff, 0xbc002f7, 0xbc002f00, 0xc002f000, 0xbfff000b, 0x2f2fffc, 0x2f000bc0, 0xf000bc00, 0xbc002, 0xfffeffff, 0xb, 
//char='Ж' offset=(0, 7) width=17 height=18 xadvance=16.7031
//.WWo...OWo...OWO.
//.OWO...OWo...WW..
//..WWo..OWo..OWO..
//..oWW..OWo..WW...
//...WWo.OWo.OWO...
//...oWW.OWo.WW....
//....WWoOWoOWo....
//....oWWWWOWW.....
//.....WWWWWWO.....
//....OWWWWWWWo....
//....WWoOWoOWW....
//...OWO.OWo.WWo...
//..oWW..OWo.oWW...
//..WWO..OWo..WWO..
//.oWW...OWo..oWW..
//.WWO...OWo...WWo.
//.WW....OWo...OWW.
//OWW....OWo....WWo
0xb807807c, 0xf01e02e0, 0xe0781f00, 0xc1e0f402, 0x8787c003, 0x1e3d000b, 0x79f0000f, 0xff40001e, 0xfc00003e, 0xf80000bf, 0xf00007ff, 0xe0003e79, 0xd001f1e2, 0xc00f4783, 0x40bc1e0b, 0x3d0780f, 0x1f01e02f, 0xf807803c, 0xc01e00f8, 0x7, 
//char='З' offset=(0, 7) width=10 height=18 xadvance=11.0938
//.oOWWWO...
//.WWWWWWWo.
//.oo...OWW.
//.......WWo
//.......WWo
//.......WWo
//......WWW.
//..oWWWWW..
//..oWWWWo..
//.....oWWO.
//.......WWo
//.......oWO
//.......oWW
//.......oWW
//.......WWO
//.Oo...OWWo
//oWWWWWWWo.
//.oOWWWO...
0xffc02fe4, 0x3e0141f, 0xc0007c00, 0x7c0007, 0xffd03f0, 0x40007fd0, 0x7c0002f, 0x4000b400, 0xf4000f, 0x7e018bc0, 0xfe41fffd, 0x2, 
//char='И' offset=(2, 7) width=11 height=18 xadvance=15.0938
//WWo......WW
//WWo.....WWW
//WWo....oWWW
//WWo....WWWW
//WWo...OWWWW
//WWo...WWoWW
//WWo..OWooWW
//WWo..WW.oWW
//WWo.OWo.oWW
//WWo.WW..oWW
//WWoOWo..oWW
//WWoWW...oWW
//WWWWO...oWW
//WWWW....oWW
//WWWO....oWW
//WWW.....oWW
//WWO.....oWW
//WWo.....oWW
0x7fc001f, 0xf401ffc0, 0x1fff007f, 0x7c07ffe0, 0x7fd781ff, 0x1e1ff4f0, 0xff43c7fd, 0xf7fd079, 0xfd02fff4, 0xbff403f, 0xf400ffd0, 0x7fd002f, 0xf40, 
//char='Й' offset=(2, 1) width=11 height=24 xadvance=15.0938
//...o...oo..
//..oWo..WW..
//...WWOWWo..
//....OWWo...
//...........
//...........
//WWo......WW
//WWo.....WWW
//WWo....oWWW
//WWo....WWWW
//WWo...OWWWW
//WWo...WWoWW
//WWo..OWooWW
//WWo..WW.oWW
//WWo.OWo.oWW
//WWo.WW..oWW
//WWoOWo..oWW
//WWoWW...oWW
//WWWWO...oWW
//WWWW....oWW
//WWWO....oWW
//WWW.....oWW
//WWO.....oWW
//WWo.....oWW
0x74014040, 0x1fbc00f0, 0x1f800, 0x0, 0x7fc001f0, 0x401ffc00, 0xfff007ff, 0xc07ffe01, 0xfd781ff7, 0xe1ff4f07, 0xf43c7fd1, 0xf7fd079f, 0xd02fff40, 0xbff403ff, 0x400ffd00, 0x7fd002ff, 0xf400, 
//char='К' offset=(2, 7) width=12 height=18 xadvance=13.375
//WWO....oWW..
//WWO....WWo..
//WWO...OWW...
//WWO..oWW....
//WWO..WWo....
//WWO.OWO.....
//WWOoWW......
//WWOWWo......
//WWWWW.......
//WWWWWO......
//WWOoWWO.....
//WWO.OWWo....
//WWO..OWW....
//WWO...WWO...
//WWO...oWWo..
//WWO....WWW..
//WWO....oWWo.
//WWO.....OWW.
0x2f0f402f, 0xe02f07c0, 0xf42f03, 0x2f007c2f, 0xf6f002e, 0x7ef00, 0xff0003ff, 0x2f6f000b, 0x7e2f00, 0x2f00f82f, 0xd02f02f0, 0xfc02f07, 0x2f1f402f, 0x3e00, 
//char='Л' offset=(0, 7) width=13 height=18 xadvance=15.0469
//....OWWWWWWWW
//....OWWWWWWWW
//....OWO...oWW
//....OWO...oWW
//....OWO...oWW
//....OWO...oWW
//....OWO...oWW
//....OWO...oWW
//....OWO...oWW
//....WWo...oWW
//....WWo...oWW
//....WW....oWW
//...oWW....oWW
//...OWO....oWW
//..oWWo....oWW
//.oWWW.....oWW
//OWWW......oWW
//OWO.......oWW
0x3fffe00, 0xe00ffff8, 0xb803d02, 0xd02e00f4, 0xf40b803, 0x803d02e0, 0x2e00f40b, 0x407c03d0, 0x3d01f00f, 0x40f403c0, 0x2e03d00f, 0x7d0f40, 0xf400fd3d, 0xbbd000fe, 0xf4000, 
//char='М' offset=(1, 7) width=17 height=18 xadvance=18.875
//.oWWo.......oWW..
//.oWWO.......WWWo.
//.oWWW.......WWWo.
//.OWWWo.....OWWWo.
//.OWOWW.....WWOWo.
//.OWoWW....oWOOWO.
//.OWooWO...OWooWO.
//.WWo.WW...WW.oWO.
//.WWo.OW..oWO.oWO.
//.WWo.oWO.OWo.oWO.
//.WW...WW.WW..oWW.
//.WW...OWoWO..oWW.
//.WW...oWWWo..oWW.
//.WW....WWW...oWW.
//.WW....WWO...oWW.
//.WW....ooo....WW.
//.WW...........WW.
//.WW...........WW.
0x3d0001f4, 0xfc000bd0, 0xf0003f41, 0xe001fe07, 0xc00fb81f, 0x403de07b, 0x2d782eb, 0xf1f0b5e, 0x387c2d3c, 0xd1f0b4b4, 0x3c2d1e2, 0xf0f43cf, 0x3c3d0b78, 0xf0f41fd0, 0xc3d03f00, 0xf40bc03, 0x3c01500f, 0xf000003c, 0xc00000f0, 0x3, 
//char='Н' offset=(2, 7) width=11 height=18 xadvance=14.9688
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWWWWWWWWWW
//WWWWWWWWWWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
//WWO.....OWW
0xbfe002f, 0xe002ff80, 0x2ff800bf, 0x800bfe00, 0xbfe002ff, 0xfffff800, 0xffffffff, 0xbfe002, 0xfe002ff8, 0x2ff800b, 0xf800bfe0, 0xbfe002f, 0xf80, 
//char='О' offset=(1, 7) width=14 height=18 xadvance=15.7188
//....OWWWOo....
//...WWWWWWWO...
//..WWWo..OWWO..
//.oWW.....oWWo.
//.WWO......WWO.
//.WWo......OWW.
//oWW.......oWW.
//oWW.......oWW.
//OWW.......oWWo
//OWW.......oWWo
//oWW.......oWW.
//oWW.......oWW.
//.WWo......OWW.
//.WWO......WWO.
//.OWW.....oWWo.
//..WWWo..oWWO..
//...WWWWWWWO...
//....OWWWWo....
0x6fe00, 0xf002fffc, 0xf40be07, 0xbc1f40, 0x7c2f0, 0xd0003d3e, 0x3d0003d3, 0xe7d0003e, 0x3d7d0003, 0x3d3d000, 0x7c3d00, 0xbc3e0, 0xf400f82f, 0xbd07f01, 0x2fffc0, 0x7fe0, 
//char='П' offset=(2, 7) width=11 height=18 xadvance=14.625
//WWWWWWWWWWo
//WWWWWWWWWWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
//WWO.....WWo
0xffdfffff, 0xf002f7ff, 0x2f7c00bd, 0xc00bdf00, 0xbdf002f7, 0x2f7c00, 0xf7c00bdf, 0xbdf002, 0xdf002f7c, 0x2f7c00b, 0x7c00bdf0, 0xbdf002f, 0x7c0, 
//char='Р' offset=(2, 7) width=10 height=18 xadvance=12.6094
//OWWWWWO...
//WWWWWWWWo.
//WWO..oWWW.
//WWO....WWo
//WWO....WWO
//WWO....OWO
//WWO....WWO
//WWO...oWWo
//WWO..oWWW.
//WWWWWWWWo.
//WWWWWWO...
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
0xfff02ffe, 0xf3f42f1f, 0xc02f7c02, 0x2fb802fb, 0x7d02fbc0, 0xfff3f42f, 0xf02fff1f, 0x2f0002, 0x2f0002f0, 0x2f000, 0x2f0002f, 0x0, 
//char='С' offset=(1, 7) width=11 height=18 xadvance=12.1875
//....OWWWWo.
//..oWWWWWWWo
//..WWWo..oO.
//.OWW.......
//.WWO.......
//oWW........
//oWW........
//oWW........
//OWW........
//OWW........
//oWW........
//oWW........
//.WWo.......
//.WWO.......
//.OWW.......
//..WWWo...Oo
//...WWWWWWWO
//....OWWWWO.
0xf407fe00, 0x907f07ff, 0xbc0003e0, 0xf4000, 0xf40003d0, 0x3e0000, 0xd0000f80, 0xf40003, 0x7c00, 0xf80002f, 0x601fc000, 0x802fffc0, 0x2ff, 
//char='Т' offset=(0, 7) width=11 height=18 xadvance=11.0625
//OWWWWWWWWWO
//OWWWWWWWWWO
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
//....OWO....
0xffaffffe, 0x2e00bff, 0xb800, 0xb80002e, 0x2e000, 0x2e0000b8, 0xb8000, 0xb80002e0, 0x2e0000, 0xe0000b80, 0xb80002, 0x80002e00, 0xb, 
//char='У' offset=(0, 7) width=12 height=18 xadvance=12.3438
//.WWo.....OWO
//.OWO.....WWo
//.oWW.....WW.
//..WW....oWW.
//..WWo...OWO.
//..oWW...WW..
//...WW..oWW..
//...OWO.OWO..
//...oWW.WW...
//....WWOWW...
//....OWWWO...
//.....WWW....
//.....OWO....
//.....WWo....
//....oWW.....
//...oWWO.....
//.OWWWW......
//.OWWO.......
0xb8b8007c, 0xf47c00, 0x3d00f03c, 0xd02e01f0, 0x43c00f03, 0xb8b800f, 0x3cf40, 0xfe0003ef, 0xfc0002, 0xb800, 0x3d00007c, 0x2f4000, 0xf8000ff8, 0x2, 
//char='Ф' offset=(1, 5) width=15 height=20 xadvance=17
//...............
//......OWO......
//......OWO......
//....OWWWWWO....
//..oWWWWWWWWWo..
//.oWWO.OWO.OWWo.
//.WWO..OWO..OWW.
//oWW...OWO...WWo
//OWO...OWO...OWO
//OWO...OWO...OWO
//WWO...OWO...OWW
//OWO...OWO...OWO
//OWW...OWO...WWO
//oWW...OWO...WWo
//.WWO..OWO..OWW.
//..WWWoOWOoWWW..
//...WWWWWWWWW...
//....oOWWWOo....
//......OWO......
//......OWO......
0x0, 0xb800, 0x2e00, 0xd000bff8, 0xbd01ffff, 0xbc1f8b8, 0x80f4f82e, 0xe02e7c0b, 0xb80bae02, 0x2e02fb80, 0xb80bbe0, 0x2e03eb8, 0xc0b80f6f, 0xf82e0bc7, 0xfdb9fc0, 0xffffc0, 0x6fe40, 0x2e00, 0xb80, 
//char='Х' offset=(0, 7) width=12 height=18 xadvance=12.2344
//.WW......WWo
//.OWO....OWO.
//..WW....WWo.
//..OWO..oWW..
//..oWW..WWo..
//...OWOoWW...
//...oWWWWo...
//....OWWW....
//....oWWO....
//....OWWW....
//....WWWWo...
//...OWOoWW...
//...WW..WWo..
//..OWO..oWW..
//..WW....WWo.
//.OWO....OWO.
//.WWo.....WW.
//oWW......OWO
0xb87c003c, 0xf02e00, 0xf42e01f, 0x8007c3d0, 0xff4003db, 0xfe0001, 0xbd00, 0xff0000fe, 0x3db8001, 0xe007c3c0, 0xf00f42, 0x2e00b81f, 0x3d3c007c, 0xb800, 
//char='Ц' offset=(2, 7) width=13 height=23 xadvance=14.8906
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWO.....WWo..
//WWWWWWWWWWWW.
//WWWWWWWWWWWW.
//..........WW.
//..........WW.
//..........WW.
//..........WW.
//..........WW.
0xbc1f002f, 0x2f07c00, 0xc00bc1f0, 0x1f002f07, 0xf07c00bc, 0xbc1f002, 0x2f07c0, 0x7c00bc1f, 0xc1f002f0, 0x2f07c00b, 0xbc1f00, 0xf002f07c, 0x7c00bc1, 0xfcffffff, 0x3ffff, 0xf00, 0xf000003c, 0x3c00000, 0xf0000, 
//char='Ч' offset=(1, 7) width=11 height=18 xadvance=13.2813
//OWO....oWW.
//OWO....oWW.
//OWO....oWW.
//OWO....oWW.
//OWO....oWW.
//OWO....oWW.
//OWO....oWW.
//oWW....oWW.
//oWW....oWW.
//.WWO...oWW.
//.oWWWWWWWW.
//..oOWWWOWW.
//.......oWW.
//.......oWW.
//.......oWW.
//.......oWW.
//.......oWW.
//.......oWW.
0xb8f402e, 0xf402e3d0, 0x2e3d00b8, 0xd00b8f40, 0xf4f402e3, 0x403d3d00, 0x43d02f0f, 0xfe40ffff, 0xf40003e, 0x3d000, 0x3d0000f4, 0xf4000, 0x3d0, 
//char='Ш' offset=(2, 7) width=16 height=18 xadvance=20.0938
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWO....WWo...oWW
//WWWWWWWWWWWWWWWW
//WWWWWWWWWWWWWWWW
0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xf407c02f, 0xffffffff, 0xffffffff, 
//char='Щ' offset=(2, 7) width=18 height=23 xadvance=20.4063
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWO....WWo...oWW..
//WWWWWWWWWWWWWWWWWO
//WWWWWWWWWWWWWWWWWO
//...............OWO
//...............OWO
//...............OWO
//...............OWO
//...............OWO
0xf407c02f, 0x407c02f0, 0x7c02f0f, 0x7c02f0f4, 0xc02f0f40, 0x2f0f407, 0x2f0f407c, 0xf0f407c0, 0xf407c02, 0xf407c02f, 0x407c02f0, 0x7c02f0f, 0x7c02f0f4, 0xc02f0f40, 0x2f0f407, 0x2f0f407c, 0xf0f407c0, 0xf407c02, 0xffffffff, 0xfffffffb, 0xbf, 0xb80, 0xb800, 0xb8000, 0xb80000, 0xb800000, 
//char='Ъ' offset=(0, 7) width=14 height=18 xadvance=14.1563
//OWWWWW........
//OWWWWW........
//...oWW........
//...oWW........
//...oWW........
//...oWW........
//...oWWWWWOo...
//...oWWWWWWWO..
//...oWW..oOWWo.
//...oWW....OWW.
//...oWW....oWW.
//...oWW.....WWo
//...oWW.....WWo
//...oWW....oWW.
//...oWW....OWW.
//...oWW..oOWWo.
//...oWWWWWWWO..
//....OWWWWOo...
0xe0000ffe, 0x400000ff, 0xf400000f, 0xf400000, 0xf40000, 0x1bff4000, 0xbfff400, 0x1f90f40, 0x403e00f4, 0xf403d00f, 0xf407c00, 0xf407c0, 0xe00f403d, 0x1f90f403, 0xbfff40, 0x1bfe0, 
//char='Ы' offset=(2, 7) width=16 height=18 xadvance=19.5
//WWO..........WWo
//WWO..........WWo
//WWO..........WWo
//WWO..........WWo
//WWO..........WWo
//WWO..........WWo
//WWWWWWO......WWo
//WWWWWWWWo....WWo
//WWO..oWWW....WWo
//WWO....WWo...WWo
//WWO....WWO...WWo
//WWO....OWW...WWo
//WWO....OWW...WWo
//WWO....OWO...WWo
//WWO....WWo...WWo
//WWO..oWWW....WWo
//WWWWWWWWo....WWo
//OWWWWWO......WWo
0x7c00002f, 0x7c00002f, 0x7c00002f, 0x7c00002f, 0x7c00002f, 0x7c00002f, 0x7c002fff, 0x7c01ffff, 0x7c03f42f, 0x7c07c02f, 0x7c0bc02f, 0x7c0f802f, 0x7c0f802f, 0x7c0b802f, 0x7c07c02f, 0x7c03f42f, 0x7c01ffff, 0x7c002ffe, 
//char='Ь' offset=(2, 7) width=10 height=18 xadvance=12.7344
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWO.......
//WWWWWWO...
//WWWWWWWWo.
//WWO..oWWW.
//WWO....WWo
//WWO....WWO
//WWO....OWW
//WWO....OWW
//WWO....OWO
//WWO....WWo
//WWO..oWWW.
//WWWWWWWWo.
//OWWWWWO...
0x2f0002f, 0xf0002f00, 0x2f0002, 0xff0002f0, 0x1ffff02f, 0x2f3f42f, 0xfbc02f7c, 0x802ff802, 0x2fb802ff, 0x3f42f7c0, 0xffe1ffff, 0x2, 
//char='Э' offset=(0, 7) width=11 height=18 xadvance=12.4219
//.oOWWWOo...
//.WWWWWWWO..
//.oo...OWWo.
//.......OWW.
//........WWo
//........OWO
//........OWW
//...WWWWWWWW
//...WWWWWWWW
//........OWW
//........OWW
//........WWO
//........WWO
//.......oWWo
//.......WWW.
//.Oo..oWWWo.
//oWWWWWWWO..
//.oOWWWOo...
0xff006fe4, 0x7e0140bf, 0x3e0000, 0x80001f00, 0x3e0000b, 0xffc0ffff, 0xf80003f, 0x3e000, 0x2f0000bc, 0x7d000, 0x1fd060fc, 0xf902fffd, 0x1b, 
//char='Ю' offset=(2, 7) width=19 height=18 xadvance=21.5156
//WWO......OWWWOo....
//WWO....oWWWWWWWO...
//WWO....WWWo..OWWO..
//WWO...OWW.....OWW..
//WWO...WWO......WWo.
//WWO...WWo......WWO.
//WWO..oWW.......OWW.
//WWWWWWWW.......oWW.
//WWWWWWWW.......oWW.
//WWO..oWW.......oWW.
//WWO..oWW.......oWW.
//WWO...WW.......OWW.
//WWO...WWo......WWO.
//WWO...OWO......WWo.
//WWO...oWW.....OWW..
//WWO....OWWo..OWWO..
//WWO.....WWWWWWWO...
//WWO......oWWWOo....
0x1bf8002f, 0xffd00bc0, 0xfc02f02f, 0x80bc2f81, 0x2f0f800f, 0xc7c002f0, 0xf0007c0b, 0xf42f2, 0x3fffcf8, 0xffff3d00, 0xbcf4000, 0xf3d0003d, 0xf4000f42, 0x3c0bc, 0x1f02f3e, 0xb80bcbc0, 0x2f1f000, 0xbc3e003d, 0xbe07e00, 0xbfff002f, 0xfd000bc0, 0x6, 
//char='Я' offset=(0, 7) width=12 height=18 xadvance=13.3594
//....oOWWWWO.
//...OWWWWWWW.
//..OWWO...WW.
//..WWO....WW.
//..WWo....WW.
//.oWW.....WW.
//..WWo....WW.
//..WWO....WW.
//..OWWO...WW.
//...OWWWWWWW.
//....WWWWWWW.
//...oWW...WW.
//...WWO...WW.
//..oWW....WW.
//..WWO....WW.
//.oWW.....WW.
//.OWO.....WW.
//.WWo.....WW.
0x802ff900, 0xbe03fff, 0x3c02f03c, 0xf43c01f0, 0x1f03c00, 0x3c02f03c, 0x803c0be0, 0xff003fff, 0x3c0f403f, 0xd03c0bc0, 0x2f03c03, 0x3c00f43c, 0x7c3c00b8, 0x3c00, 
//char='а' offset=(1, 11) width=9 height=14 xadvance=11.2813
//.oOWWWo..
//.OWWWWWO.
//.....OWW.
//......WWo
//......OWo
//..oOWOWWo
//.WWWWWWWo
//OWWo..WWo
//WWo...OWo
//WWo...OWo
//WWo...OWo
//OWW...WWo
//.WWWWWWWo
//..OWWWWO.
0xffe01fe4, 0xf8002, 0x41e0007c, 0x9fffc7ee, 0xe01f7c1f, 0x1f7807d, 0xfc7c0f9e, 0x2ff81ff, 
//char='б' offset=(1, 4) width=11 height=21 xadvance=12.2656
//........o..
//.....OWWW..
//...OWWWWO..
//..oWWO.....
//..WWo......
//.oWW.......
//.WWo.......
//.WWo.......
//.WWOWWWO...
//.WWWWWWWW..
//oWWo..oWWo.
//oWW....OWO.
//oWW....oWW.
//oWW....oWW.
//.WW....oWW.
//.WW....oWW.
//.WWo...oWW.
//.OWO...OWO.
//.oWWo.oWWo.
//..OWWWWWO..
//...OWWWO...
0x10000, 0x2ff800fe, 0xf0002f40, 0x3d0001, 0xf00007c0, 0xbfbc0001, 0xd0ffff00, 0xf47d07, 0x4f403d2e, 0x3c3d00f, 0x3d00f0f4, 0x2e0f407c, 0x7d1f42e0, 0x800bff80, 0xbf, 
//char='в' offset=(2, 11) width=9 height=14 xadvance=11.9219
//OOWWWWo..
//WWWWWWWO.
//WWo..oWWo
//WWo...WWo
//WWo...WWo
//WWo..oWW.
//WWWWWWW..
//WWOOOWWO.
//WWo...WWO
//WWo...oWW
//WWo...OWW
//WWo...WWO
//WWWWWWWW.
//OWWWWWO..
0xfffc1ffa, 0x7df41f2, 0x7df01f7c, 0xc3fff3d0, 0xf01f2fab, 0x1ff407e, 0xffbc07fe, 0xbff8ff, 
//char='г' offset=(2, 11) width=7 height=14 xadvance=8.59375
//WWWWWWo
//WWWWWW.
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
//WWo....
0xf3ffdfff, 0x1f007c01, 0x1f007c0, 0xc01f007c, 0x7c01f007, 0x7c01f00, 0x0, 
//char='д' offset=(0, 11) width=13 height=18 xadvance=12.4688
//...OWWWWWWO..
//...OWWWWWWO..
//...OWO..OWO..
//...OWO..OWO..
//...OWo..OWO..
//...OWo..OWO..
//...WWo..OWO..
//...WWo..OWO..
//...WW...OWO..
//..oWW...OWO..
//..OWO...OWO..
//..WW....OWO..
//OWWWWWWWWWWW.
//OWWWWWWWWWWW.
//OWo.......WW.
//OWo.......WW.
//OWo.......WW.
//OWo.......OW.
0x2fff80, 0xb800bffe, 0x82e002e0, 0x2e07800b, 0xb81e00, 0xf002e07c, 0x3c00b81, 0xb80f402e, 0x2e02e00, 0xfe0b803c, 0xfff8ffff, 0x1e3ff, 0x3c00078f, 0x78f0001e, 0x38000, 
//char='е' offset=(1, 11) width=10 height=14 xadvance=11.3281
//..oOWWO...
//.oWWWWWW..
//.WWO..WWo.
//oWW...OWO.
//oWO...oWW.
//OWO...oWW.
//OWWWWWWWW.
//OWWWWWWWW.
//OWO.......
//oWW.......
//oWW.......
//.WWW...o..
//.oWWWWWWo.
//...OWWWO..
0xff402f90, 0xd1f0bc0f, 0xd02d2e03, 0xfe3d02e3, 0x3fffe3ff, 0x3d0002e, 0xc0003d00, 0xfff4040f, 0xbf801, 
//char='ж' offset=(0, 11) width=14 height=14 xadvance=13.8438
//.WW...WW...WW.
//.OWo..WW..OWo.
//..WW..WW..WW..
//..OWo.WW.OWo..
//...WW.WW.WW...
//...oWOWWOWo...
//....WWWWWW....
//...OWOWWWWo...
//...WW.WW.WW...
//..OWo.WW.OWO..
//.oWW..WW..WW..
//.OWo..WW..OWO.
//.WW...WW...WW.
//OWo...WW...OWo
0x83c0f03c, 0xf01e0f07, 0x1e00f0f0, 0xf3c0078f, 0xefb4003c, 0xfff0001, 0x1ffb800, 0x3cf3c0, 0xf40b8f1e, 0x780f0f0, 0xf03c2e0f, 0xf01e3c0, 0x78, 
//char='з' offset=(0, 11) width=9 height=14 xadvance=9.51563
//.oOWWOo..
//.WWWWWWo.
//.o...OWW.
//......WW.
//.....OWW.
//..OWWWWo.
//..WWWWO..
//.....OWO.
//......WW.
//......OWo
//......WWo
//.o...oWWo
//.WWWWWWO.
//.oWWWWo..
0xfff01be4, 0xf8041, 0x80f8003c, 0x2ff01ff, 0xf0002e00, 0x78000, 0xfc7d011f, 0x7fd0bf, 
//char='и' offset=(2, 11) width=9 height=14 xadvance=12.7031
//WW....oWO
//WW....WWO
//WW...OWWO
//WW...WWWO
//WW..OWOWO
//WW..WOoWO
//WW.OWooWO
//WWoWO.oWO
//WWOWo.oWO
//WWWW..oWO
//WWWo..oWO
//WWW...oWO
//WWo...oWO
//WW....oWO
0xc03ed00f, 0x3ef80fb, 0x3eee0fbf, 0xed78fb6c, 0xd1efb4b7, 0x7fb43fe, 0x1fb40fed, 0xb403ed0, 
//char='й' offset=(2, 5) width=9 height=20 xadvance=12.7031
//..o...o..
//.OW..oWo.
//.oWWOWW..
//..oWWWo..
//.........
//.........
//WW....oWO
//WW....WWO
//WW...OWWO
//WW...WWWO
//WW..OWOWO
//WW..WOoWO
//WW.OWooWO
//WWoWO.oWO
//WWOWo.oWO
//WWWW..oWO
//WWWo..oWO
//WWW...oWO
//WWo...oWO
//WW....oWO
0xd0e01010, 0xf403ef41, 0x7, 0xed00f000, 0xf80fbc03, 0xe0fbf03e, 0x8fb6c3ee, 0xfb4b7ed7, 0xb43fed1e, 0x40fed07f, 0x3ed01fb, 0xb4, 
//char='к' offset=(2, 11) width=9 height=14 xadvance=11.0938
//WWo...WW.
//WWo..OWO.
//WWo.oWW..
//WWo.WWo..
//WWoOWO...
//WWOWW....
//WWWWO....
//WWOWW....
//WWoOWW...
//WWo.WWO..
//WWo.oWW..
//WWo..WWO.
//WWo..oWW.
//WWo...OWO
0xe07cf01f, 0xc7c3d1f2, 0xbc0b9f07, 0xc02ff00f, 0xf9f00fb, 0xd1f0bc7c, 0x1f2f07c3, 0xb807cf4, 
//char='л' offset=(0, 11) width=11 height=14 xadvance=12.9219
//...oWWWWWWW
//...oWWWWWWW
//...oWW..oWW
//...oWW..oWW
//...oWW..oWW
//...oWO..oWW
//...OWO..oWW
//...OWO..oWW
//...WWo..oWW
//...WW...oWW
//..OWW...oWW
//.OWWo...oWW
//OWWO....oWW
//OWo.....oWW
0xd03fff40, 0xd0f40fff, 0x40f43d03, 0x42d03d0f, 0x3d0b80f, 0x7c0f42e, 0xf40f03d, 0x7e3d03e, 0xbd00bef4, 0xf4007, 
//char='м' offset=(1, 11) width=13 height=14 xadvance=15.8594
//.oWW.....oWWo
//.oWWO....OWWo
//.OWWW....WWWo
//.OWOWo..oWOWo
//.OWoWO..OWoWO
//.OW.WW..WOoWO
//.WW.OW.oWooWO
//.WW.oWoOW.oWO
//.WW..WWWW.oWO
//.WW..OWWO..WW
//.WW..oWWo..WW
//.WW...WW...WW
//.WW........WW
//.WW........WW
0xd1f400f4, 0x3f87e00b, 0x41ee1fc0, 0xde0b787b, 0xcb6c3ce2, 0x4f2d74e3, 0xfc3cb4e7, 0xbe0f2d3, 0x3c1f43cf, 0x3cf03c0f, 0xf3c000, 0xf00, 
//char='н' offset=(2, 11) width=9 height=14 xadvance=12.8438
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWWWWWWWW
//WWWWWWWWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
//WWo...oWW
0x407fd01f, 0x7fd01ff, 0x7fd01ff4, 0xffffff40, 0xd01fffff, 0x1ff407f, 0x1ff407fd, 0xf407fd0, 
//char='о' offset=(1, 11) width=10 height=14 xadvance=12.0313
//...OWWOo..
//.oWWWWWWo.
//.WWO..OWW.
//oWW....WWo
//OWW....WWO
//OWO....OWO
//OWO....OWO
//OWO....OWO
//OWO....OWO
//OWW....WWO
//oWW....WWo
//.WWO..OWW.
//.oWWWWWWo.
//...OWWOo..
0xff406f80, 0xd3e0bc1f, 0xc03e7c03, 0x2eb802eb, 0xb802eb80, 0x3eb802e, 0xc7c03dbc, 0xfff43e0b, 0x6f801, 
//char='п' offset=(2, 11) width=9 height=14 xadvance=12.4531
//WWWWWWWWo
//WWWWWWWWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo...WWo
0xfffdffff, 0x7df01f7, 0x7df01f7c, 0xdf01f7c0, 0xf01f7c07, 0x1f7c07d, 0x1f7c07df, 0x7c07df0, 
//char='р' offset=(2, 11) width=9 height=19 xadvance=12.1406
//oOWWWO...
//WWWWWWWo.
//WWo..OWW.
//WWo...WWo
//WWo...OWO
//WWo...OWW
//WWo...oWW
//WWo...oWW
//WWo...OWW
//WWo...OWO
//WWo...WWo
//WWo..OWW.
//WWWWWWWO.
//WWOWWWo..
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
0xfffc0bf9, 0x7cf81f1, 0x7ee01f7c, 0xfd01ff80, 0xe01ff407, 0x1fb807f, 0xff3e07df, 0xf07fbcbf, 0x7c001, 0x7c001f, 0x1f0, 
//char='с' offset=(1, 11) width=8 height=14 xadvance=9.17188
//...OWWWo
//..WWWWWo
//.WWW....
//oWW.....
//OWW.....
//OWO.....
//OWO.....
//OWO.....
//OWO.....
//OWW.....
//oWW.....
//.WWW....
//.oWWWWWO
//...OWWWo
0x7ff07f80, 0x3d00fc, 0x2e003e, 0x2e002e, 0x3e002e, 0xfc003d, 0x7f80bff4, 
//char='т' offset=(0, 11) width=10 height=14 xadvance=9.76563
//OWWWWWWWWo
//OWWWWWWWWo
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
//...oWW....
0xffe7fffe, 0xf407f, 0xf4000f4, 0x4000f400, 0xf4000f, 0xf4000f40, 0xf4000, 0xf4000f4, 0xf400, 
//char='у' offset=(0, 11) width=10 height=19 xadvance=10.2813
//OWW....oWW
//oWW....OWO
//.WW....OWo
//.WWo...WW.
//.OWO...WW.
//.oWW..oWO.
//..WW..OWo.
//..WWo.WW..
//..OWO.WW..
//..oWWoWO..
//...WWWWo..
//...WWWW...
//...oWWO...
//....WWo...
//....WW....
//...oWO....
//...WW.....
//OWWWO.....
//OWWO......
0x3df403e, 0xc7803cb8, 0xc0b83c07, 0xf02d0f43, 0xf1f01e0, 0x7d00f2e0, 0x7fc00b, 0x2f4003fc, 0x1f000, 0xb4000f, 0x2fe003c0, 0xbe00, 
//char='ф' offset=(1, 5) width=14 height=25 xadvance=15.2031
//.....oOO......
//.....oWO......
//.....oWO......
//.....oWO......
//.....oWO......
//.....oWO......
//.....OWOo.....
//...WWWWWWWo...
//.oWWWOWWWWWo..
//.WWO.oWO.oWW..
//oWW..oWO..OWO.
//OWO..oWO..oWW.
//WWo..oWO...WW.
//WWo..oWO...WW.
//WWo..oWO...WW.
//OWO..oWO..oWW.
//oWW..oWO..WWO.
//.WWW.oWO.OWW..
//..WWWWWWWWWo..
//...OWWWWWO....
//.....OWO......
//.....oWO......
//.....oWO......
//.....oWO......
//.....oWO......
0xa400, 0xb40, 0x400000b4, 0xb400000b, 0xb400000, 0x1b80000, 0x1fffc00, 0xc07ffbf4, 0x3d0f4b4b, 0x42e2e0b4, 0xb41f3d0b, 0xb41f3c0, 0xc0b41f3c, 0x3d0b42e3, 0xc2f0b43d, 0xf00f8b4f, 0xf8007fff, 0xb80000bf, 0xb400000, 0xb40000, 0xb4000, 0xb400, 
//char='х' offset=(0, 11) width=10 height=14 xadvance=10.1875
//oWW....OWo
//.OWO..oWW.
//..WW..OWo.
//..OWooWW..
//...WWWWo..
//...OWWW...
//...oWWo...
//...OWWW...
//...WWWWo..
//..OWooWW..
//..WW..WWo.
//.OWO..oWO.
//.WW....WW.
//oWO....OWO
0xb87803d, 0x1e0f03d, 0x7fc00f5e, 0x4003f800, 0x3f8001f, 0x5e007fc0, 0x81f0f00f, 0xc03c2d0b, 0xb802d3, 
//char='ц' offset=(2, 11) width=11 height=18 xadvance=12.3438
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWo...WWo..
//WWWWWWWWWW.
//WWWWWWWWWW.
//........WW.
//........WW.
//........WW.
//........WW.
0x7c1f01f, 0x1f01f07c, 0x1f07c07c, 0x7c07c1f0, 0x7c1f01f0, 0xf01f07c0, 0xf07c07c1, 0xc07c1f01, 0xcfffff07, 0x3ffff, 0x3c0000f0, 0xf0000, 0x3c0, 
//char='ч' offset=(1, 11) width=9 height=14 xadvance=11.7188
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//WWo...OWO
//OWO...OWO
//oWWo..OWO
//.WWWWWWWO
//..OWWWWWO
//......OWO
//......OWO
//......OWO
//......OWO
//......OWO
0x807ee01f, 0x7ee01fb, 0xbae01fb8, 0x2e07db80, 0xffe0bfff, 0xb8002, 0xb8002e, 0xb8002e0, 
//char='ш' offset=(2, 11) width=14 height=14 xadvance=17.875
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWo...WW...oWW
//WWWWWWWWWWWWWW
//WWWWWWWWWWWWWW
0xff40f01f, 0x1ff40f01, 0x1ff40f0, 0xf01ff40f, 0xf01ff40, 0x40f01ff4, 0xf40f01ff, 0xff40f01f, 0x1ff40f01, 0x1ff40f0, 0xfffff40f, 0xffffffff, 0xff, 
//char='щ' offset=(2, 11) width=16 height=18 xadvance=17.7813
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWo...WW...oWW..
//WWWWWWWWWWWWWWWo
//WWWWWWWWWWWWWWWO
//.............OWO
//.............OWO
//.............OWO
//.............OWo
0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0xf40f01f, 0x7fffffff, 0xbfffffff, 0xb8000000, 0xb8000000, 0xb8000000, 0x78000000, 
//char='ъ' offset=(0, 11) width=12 height=14 xadvance=11.875
//OWWWW.......
//OWWWW.......
//..oWW.......
//..oWW.......
//..oWW.......
//..oWWWWWO...
//..oWWWWWWW..
//..oWW...WWO.
//..oWW...oWW.
//..oWW....WW.
//..oWW...oWW.
//..oWW...WWW.
//..oWWWWWWW..
//...OWWWWO...
0xfe0003fe, 0x3d00003, 0x3d000, 0xd00003d0, 0xffd002ff, 0x2f03d00f, 0xd03d03d0, 0x3d03c03, 0x3f03d03d, 0x800fffd0, 0x2ff, 
//char='ы' offset=(2, 11) width=14 height=14 xadvance=17.4688
//WWo........WWo
//WWo........WWo
//WWo........WWo
//WWo........WWo
//WWo........WWo
//WWWWWOo....WWo
//WWWWWWWo...WWo
//WWo..OWW...WWo
//WWo...WWo..WWo
//WWo...WWo..WWo
//WWo...WWo..WWo
//WWo..OWW...WWo
//WWWWWWWo...WWo
//WWWWWOo....WWo
0xf7c0001f, 0x1f7c0001, 0x1f7c000, 0x1f7c00, 0x1bff7c0, 0xc07fff7c, 0x7c0f81f7, 0xf7c1f01f, 0x1f7c1f01, 0x81f7c1f0, 0x7fff7c0f, 0x1bff7c0, 0x7c, 
//char='ь' offset=(2, 11) width=9 height=14 xadvance=11.1719
//WWo......
//WWo......
//WWo......
//WWo......
//WWo......
//WWWWWOo..
//WWWWWWWo.
//WWo..OWW.
//WWo...WWo
//WWo...WWo
//WWo...WWo
//WWo..OWW.
//WWWWWWWo.
//OWWWWOo..
0x7c001f, 0x7c001f0, 0xfc001f00, 0xc7fff06f, 0xf01f3e07, 0x1f7c07d, 0xff3e07df, 0x6ff87f, 
//char='э' offset=(0, 11) width=9 height=14 xadvance=9.92188
//.OWWWO...
//.WWWWWW..
//.....WWW.
//......WWo
//......WWo
//......OWO
//..WWWWWWO
//..OWWWWWO
//......OWO
//......WWo
//.....oWW.
//.o..oWWO.
//.WWWWWW..
//.OWWWO...
0xfff00bf8, 0xfc000, 0x1f0007c, 0x2fff0b80, 0xe000bff8, 0x4007c002, 0xfc2f410f, 0x2fe03f, 
//char='ю' offset=(2, 11) width=14 height=14 xadvance=17.0469
//WWo....OWWOo..
//WWo...WWWWWWo.
//WWo..OWW..OWW.
//WWo..WWo...WWo
//WWo.oWW....WWO
//WWo.oWW....OWO
//WWWWWWO....OWW
//WWWWWWO....OWW
//WWo.oWW....OWO
//WWo.oWW....WWO
//WWo..WWo...WWo
//WWo..OWW..OWW.
//WWo...WWWWWWo.
//WWo....OWWOo..
0xf06f801f, 0x1f1fff01, 0xc1f3e0f8, 0x3d1f7c07, 0x3d1fbc0, 0x802fffb8, 0xf802ffff, 0xfb803d1f, 0x1fbc03d1, 0x81f7c07c, 0xf01f3e0f, 0xf801f1ff, 0x6, 
//char='я' offset=(1, 11) width=9 height=14 xadvance=11.4844
//..oOWWWOo
//.OWWWWWWo
//.WWo..OWo
//oWW...OWo
//OWW...OWo
//oWW...OWo
//.WWO..OWo
//.oWWWWWWo
//..OWWWWWo
//..WW..OWo
//.OWO..OWo
//.WWo..OWo
//oWW...OWo
//OWO...OWo
0xffe1bf90, 0xf5e07c7, 0xf5e03e78, 0x1e0bc780, 0xffe07ffd, 0xb8783c1, 0x3d781f1e, 0x780b9e0, 
//char='°' offset=(0, 6) width=7 height=6 xadvance=7.48438
//..OWWo.
//.WWOOWo
//oWo..WW
//oWo..WW
//.WWOOWo
//..OWWo.
0xd7af07e0, 0xbcf077c1, 0x1f81e, 
//char='±' offset=(1, 12) width=10 height=13 xadvance=11.1719
//...oWO....
//...oWO....
//...oWO....
//...oWO....
//WWWWWWWWW.
//WWWWWWWWW.
//...oWO....
//...oWO....
//...oWO....
//....o.....
//..........
//WWWWWWWWW.
//WWWWWWWWW.
0xb4000b40, 0xb4000, 0xffff00b4, 0x403ffff3, 0xb4000b, 0x10000b40, 0xf0000000, 0xffff3fff, 0x3, 
};
