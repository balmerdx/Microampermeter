#pragma once
extern const uint32_t font_condensed59[];