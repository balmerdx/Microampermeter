#pragma once

void VoltageInit();

void VoltageGet(float* Vout, float* Vbat);
